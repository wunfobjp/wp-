// content.js - 追剧助手完整版（修复 zxfscl.com 记录问题）
// 功能：自动续播、进度同步、跳过片头片尾、自动下一集、快捷键快进快退、站点预设匹配
(function() {
    // ======================== 全局配置 ========================
    let config = {
        // 原有配置
        autoUpdateFav: true,
        onlySaveMaxEpisode: false,
        
        // 新增：自动跳过相关
        autoSkipEnable: false,      // 是否启用跳过功能
        enableIntro: true,          // 启用片头跳过
        enableOutro: true,          // 启用片尾跳过
        autoRestart: false,         // 循环播放（结束后重置到片头）
        autoPlayNext: false,        // 自动播放下集
        introTime: 90,              // 片头时长（秒）
        outroTime: 0,               // 片尾时长（秒）
        manualSkipTime: 90,         // 手动快进/快退秒数
        minDuration: 300,           // 最小视频时长（秒），短于该值不触发跳过
        
        // 快捷键配置（默认 Shift+左右箭头）
        keyForward: { code: 'ArrowRight', shift: true, ctrl: false, alt: false },
        keyRewind:  { code: 'ArrowLeft',  shift: true, ctrl: false, alt: false },
        
        // 站点预设方案
        savedPresets: [],
        autoApplyPreset: true,
        lastActivePreset: "",
        
        // URL 递增跳转的网站列表（如 ["video.myvip.run", "example.com"]）
        urlIncrementDomains: [],
        
        // 自定义规则
        customTagRules: [],
        customSeriesRules: []
    };
    
    // ======================== 状态变量 ========================
    let lastUrl = window.location.href;
    let isJumped = false;           // 是否已自动续播
    let jumpAttempted = false;
    let jumpCompleted = false;
    let jumpInProgress = false;
    let jumpTimeout = null;
    
    // 跳过片头片尾相关状态
    let hasSkippedIntro = false;
    let hasTriggeredRestart = false;
    let videoLoadStartTime = 0;
    let restartCooldownTime = 0;
    let isSwitchingEpisode = false;
    let lastCheckTime = 0;
    
    let boundVideos = new WeakSet();
    let cachedTopTitle = null;
    let cachedTopUrl = null;
    
    // ======================== 辅助函数 ========================
    function numberToChinese(num) {
        const chineseNums = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
        if (num === 0) return '零';
        if (num <= 10) return chineseNums[num];
        if (num < 20) return '十' + (num % 10 === 0 ? '' : chineseNums[num % 10]);
        const tens = Math.floor(num / 10);
        const ones = num % 10;
        return chineseNums[tens] + '十' + (ones === 0 ? '' : chineseNums[ones]);
    }
    
    function chineseToNumber(chStr) {
        const chMap = { '一':1, '二':2, '三':3, '四':4, '五':5, '六':6, '七':7, '八':8, '九':9, '十':10 };
        if (chStr.length === 1) return chMap[chStr] || 0;
        if (chStr === '十') return 10;
        if (chStr.startsWith('十')) return 10 + (chMap[chStr[1]] || 0);
        if (chStr.endsWith('十')) return (chMap[chStr[0]] || 0) * 10;
        if (chStr.includes('十')) {
            const parts = chStr.split('十');
            const left = parts[0] ? chMap[parts[0]] : 1;
            const right = parts[1] ? chMap[parts[1]] : 0;
            return left * 10 + right;
        }
        return 0;
    }
    
    async function safeSendMessage(message) {
        if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) return null;
        try { return await chrome.runtime.sendMessage(message); } catch(e) { return null; }
    }
    
    function safeStorageGet(keys, callback) {
        if (!chrome || !chrome.storage || !chrome.storage.local) { callback({}); return; }
        chrome.storage.local.get(keys, callback);
    }
    
    function normalizeEpisode(ep) {
        const match = ep.match(/\d+/);
        if (match) return `第${parseInt(match[0])}集`;
        return ep;
    }
    
    function showToast(text) {
        let toast = document.getElementById('zhui-ju-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'zhui-ju-toast';
            toast.style.cssText = `
                position: fixed; top: 15%; left: 50%; transform: translateX(-50%);
                background-color: rgba(0, 174, 236, 0.9); color: white; padding: 8px 20px;
                border-radius: 20px; font-size: 14px; z-index: 2147483647;
                pointer-events: none; transition: opacity 0.3s; font-family: sans-serif;
                box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            `;
            document.body.appendChild(toast);
        }
        toast.innerText = text;
        toast.style.opacity = '1';
        clearTimeout(window.toastTimeout);
        window.toastTimeout = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
    }
    
    function showJumpTip(seconds) {
        const min = Math.floor(seconds/60), sec = seconds%60;
        const tip = document.createElement('div');
        tip.innerHTML = `🎬 已为你续播到 ${min}分${sec}秒`;
        Object.assign(tip.style, {
            position:'fixed', top:'35px', left:'50%', transform:'translateX(-50%)',
            backgroundColor:'rgba(0,174,236,0.95)', color:'white', padding:'10px 25px',
            borderRadius:'30px', zIndex:'2147483647', fontSize:'14px', fontWeight:'bold',
            boxShadow:'0 4px 15px rgba(0,0,0,0.2)', pointerEvents:'none'
        });
        document.body.appendChild(tip);
        setTimeout(() => { tip.style.opacity='0'; setTimeout(()=>tip.remove(),500); }, 3000);
    }
    
    // ======================== 集数提取（增强版，支持 /cid/数字-数字-数字.html） ========================
    function extractEpisodeFromURL(url) {
        if (!url) return null;
        function validNum(num) {
            let n = parseInt(num, 10);
            return n > 0 && n <= 9999;
        }
        // 新增：匹配 /cid/数字-数字-数字.html，取最后一个数字作为集数
        let match = url.match(/\/cid\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        
        match = url.match(/\/play\/\d+\/\d+\/(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/vod-play\/\d+-\d+-(\d+)\//);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/play\/\d+-(\d+)-(\d+)\.html/);
        if (match && validNum(match[2])) return `第${parseInt(match[2])}集`;
        match = url.match(/[?&]ep=第(\d+)集/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/vodplay\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/play\/\d+_(\d+)_(\d+)\.html/);
        if (match && validNum(match[2])) return `第${parseInt(match[2])}集`;
        match = url.match(/\/play\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/player\/vod\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        const patterns = [
            /[\/-](\d{1,4})(?:\/|$)/,
            /[?&]ep(?:isode)?=(\d{1,4})/i,
            /[\/-]ep(\d{1,4})/i,
            /[\/-]p(\d{1,4})/i,
        ];
        for (const pattern of patterns) {
            const m = url.match(pattern);
            if (m && validNum(m[1])) return `第${parseInt(m[1])}集`;
        }
        return null;
    }
    
    function tryExtractEpisodeFromDOM() {
        function validNum(num) {
            let n = parseInt(num, 10);
            return n > 0 && n <= 9999;
        }
        const oleActiveLi = document.querySelector('li.active_s.active_b.active');
        if (oleActiveLi) {
            let title = oleActiveLi.getAttribute('title');
            if (title) {
                let match = title.match(/第(\d+)集/);
                if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
            }
            let text = oleActiveLi.innerText.trim();
            let match = text.match(/第(\d+)集/);
            if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        }
        const activeEpisode = document.querySelector('.episode-link.bg-dark-700\\/60.text-white');
        if (activeEpisode) {
            let episodeNum = activeEpisode.getAttribute('data-episode');
            if (episodeNum && !isNaN(parseInt(episodeNum)) && parseInt(episodeNum) <= 9999) {
                return `第${parseInt(episodeNum)}集`;
            }
            const span = activeEpisode.querySelector('span');
            if (span && span.innerText) {
                let text = span.innerText.trim();
                let match = text.match(/^(\d{1,4})$/);
                if (match && parseInt(match[1]) <= 9999) return `第${parseInt(match[1])}集`;
            }
        }
        const moovieLink = document.querySelector('.ep-btn.active');
        if (moovieLink && moovieLink.innerText) {
            let text = moovieLink.innerText.trim();
            let match = text.match(/(第\s*\d+\s*[集话期])|(\d+)\s*[集话期]?/);
            if (match) {
                let ep = match[0];
                if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                if (!/线路|资源|播放|更新/.test(ep)) return ep;
            }
        }
        const hemayiLink = document.querySelector('.stui-play__list li.active a');
        if (hemayiLink && hemayiLink.innerText) {
            let text = hemayiLink.innerText.trim();
            let match = text.match(/(第\s*\d+\s*[集话期])|(\d+)\s*[集话期]?/);
            if (match) {
                let ep = match[0];
                if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                if (!/线路|资源|播放|更新/.test(ep)) return ep;
            }
        }
        const ttdm6Link = document.querySelector('.module-play-list-link.active');
        if (ttdm6Link && ttdm6Link.innerText) {
            let text = ttdm6Link.innerText.trim();
            let match = text.match(/(第\s*\d+\s*[集话期])|(\d+)\s*[集话期]?/);
            if (match) {
                let ep = match[0];
                if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                if (!/线路|资源|播放|更新/.test(ep)) return ep;
            }
        }
        const selectors = [
            '.play-item.cont.active li.active a', 'li.active a', 'li.on a',
            '.module-play-list-link.current', '.episode-item-active', '[aria-current="page"]',
            '.stui-play__list li.active a', '.playlist li.active a', '.ep-list li.active a',
            '.episode-item-active', '.active', '.on', '.current'
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText) {
                let text = el.innerText.trim();
                let match = text.match(/(第\s*\d+\s*[集话期])|(\d+)\s*[集话期]?/);
                if (match) {
                    let ep = match[0];
                    if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                    if (!/线路|资源|播放|更新/.test(ep)) return ep;
                }
            }
        }
        return null;
    }
    
    function waitForElement(selector, timeout = 10000, interval = 200) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el) return resolve(el);
                if (Date.now() - start >= timeout) return resolve(null);
                setTimeout(check, interval);
            };
            check();
        });
    }
    
    async function getEpisodeFromDOMWithRetry() {
        const url = window.location.href;
        if (url.match(/\/vod\/\d+\/$/)) {
            const activeLink = await waitForElement('.module-play-list-link.active', 10000, 200);
            if (activeLink) {
                const text = activeLink.innerText.trim();
                let match = text.match(/(第\s*\d+\s*[集话期])|(\d+)\s*[集话期]?/);
                if (match) {
                    let ep = match[0];
                    if (/^\d+$/.test(ep)) ep = `第${parseInt(ep)}集`;
                    if (!/线路|资源|播放|更新/.test(ep)) return ep;
                }
            }
            return "正片";
        }
        let maxRetries = 5, delay = 300;
        if (url.includes('hemayi.com') || url.includes('4kvm.tv') || url.includes('beijingbaroque.com') || url.includes('yao-da.com') || url.includes('gangjuw.tv') || url.includes('olevod.com')) {
            maxRetries = 10; delay = 500;
        }
        for (let i = 0; i < maxRetries; i++) {
            const ep = tryExtractEpisodeFromDOM();
            if (ep) return ep;
            await new Promise(r => setTimeout(r, delay));
        }
        return "正片";
    }
    
    // ======================== 剧名清洗（为 zxfscl.com 添加 DOM 提取） ========================
    function cleanSeriesName(rawTitle, url) {
        if (!rawTitle) return "未知视频";
        
        // ===== 新增：针对 zxfscl.com 特殊处理 =====
        if (url.includes('zxfscl.com')) {
            try {
                // 从页面元素中提取剧名（更准确）
                const seriesEl = document.querySelector('.player-tips h5 a');
                if (seriesEl && seriesEl.innerText) {
                    let series = seriesEl.innerText.trim();
                    if (series) return series;
                }
                // 备选：面包屑导航最后一个链接
                const breadcrumb = document.querySelector('.top-weizhi a:last-child');
                if (breadcrumb && breadcrumb.innerText) {
                    let series = breadcrumb.innerText.trim();
                    if (series) return series;
                }
                // 从标题中提取《xxx》
                const titleMatch = rawTitle.match(/《(.+?)》/);
                if (titleMatch) return titleMatch[1];
            } catch(e) {}
        }
        // ===== 原有代码继续 =====
        let titleTemp = rawTitle.trim();
        const codePattern = /\b(?:FC2|FC2-PPV|HEYZO|Caribbean|一本道|加勒比|天然むすめ|東京熱|Tokyo-Hot)[-_]?\d+/i;
        if (codePattern.test(titleTemp)) {
            let cleaned = titleTemp.replace(/第\d+集/g, '').trim();
            if (cleaned) return cleaned;
            return titleTemp;
        }
        let seasonText = '', langTag = "";
        const seasonPattern = /(?:第\s*(\d+)\s*季|第\s*([一二三四五六七八九十]+)\s*季|(\d+)\s*季|([一二三四五六七八九十]+)\s*季)/i;
        let match = titleTemp.match(seasonPattern);
        if (match) {
            let seasonNum = null;
            if (match[1]) seasonNum = parseInt(match[1],10);
            else if (match[2]) seasonNum = chineseToNumber(match[2]);
            else if (match[3]) seasonNum = parseInt(match[3],10);
            else if (match[4]) seasonNum = chineseToNumber(match[4]);
            if (seasonNum && seasonNum>=1 && seasonNum<=99) {
                const chineseSeason = numberToChinese(seasonNum);
                seasonText = `第${chineseSeason}季`;
                titleTemp = titleTemp.replace(seasonPattern, '').trim();
            }
        }
        if (url.includes('keke1.app')) {
            try {
                const detailLink = document.querySelector('.detail-title a strong, .play-box-side-header .detail-title a strong, a[href^="/detail/"] strong');
                if (detailLink && detailLink.innerText) {
                    let series = detailLink.innerText.trim();
                    if (series) {
                        if (series.includes('第') && series.includes('季')) return series;
                        return series + seasonText;
                    }
                }
            } catch(e) {}
        }
        let title = titleTemp;
        if (url.includes('4kvm.tv') && title.includes(':')) title = title.split(':')[0];
        if (url.includes('gangjuw.tv')) { const idx = title.indexOf('第'); if(idx>0) title = title.substring(0,idx); }
        if (url.includes('olevod.com')) {
            const langMatch = title.match(/[【【](国语|粤语)[】】]/);
            if (langMatch) { langTag = langMatch[1]; title = title.replace(/[【【](?:国语|粤语)[】】]/g,'').trim(); }
            title = title.replace(/[【【][^】】]*[】】]/g,'').trim();
        }
        if (!langTag) { if(title.includes("粤语")) langTag="粤语"; else if(title.includes("国语")) langTag="国语"; }
        const tailNoise = /(\.com|\.app|\.net|\.cc|免费|爱看|在线|高清|完整|播放|正在|视频|官方|最新|频道|4k影视|4K影视|影视|可可影视|线上看|港剧网)/i;
        const tailMatch = title.match(tailNoise);
        if (tailMatch) title = title.substring(0, tailMatch.index);
        const bracketMatch = title.match(/《(.*?)》/);
        if (bracketMatch) title = bracketMatch[1];
        title = title.replace(/[《》()（）\[\]【】\s\-\|_—]/g, "").trim();
        const noiseWords = [
            /在线观看|免费播放|高清|完整版|正片|正在播放|正在|播放/gi,
            /电视剧|电影|动漫|综艺|机器人|ikanbot|可可影视|影牛|欧乐影院|olevod/gi,
            /粤语/g, /国语/g, /免费/g, /爱看/g, /4k影视|4K影视|影视/g, /\d{5,}/g
        ];
        noiseWords.forEach(word => title = title.replace(word, ""));
        let finalSeries = (title + langTag).trim();
        if (!finalSeries) finalSeries = "未知视频";
        if (seasonText) finalSeries = finalSeries + seasonText;
        return finalSeries;
    }
    
    async function getVideoInfo(finalTitle, finalUrl) {
        let episode = extractEpisodeFromURL(finalUrl);
        if (!episode) episode = await getEpisodeFromDOMWithRetry();
        const series = cleanSeriesName(finalTitle, finalUrl);
        console.log(`[追剧助手] 剧名: ${series}, 集数: ${episode}`);
        return { series, episode };
    }
    
    // ======================== 自动续播（原有） ========================
    async function autoJump(video, retryCount = 0) {
        if (isJumped || jumpCompleted) return;
        if (video.currentTime > 15) return;
        
        let finalTitle = document.title;
        let finalUrl = window.location.href;
        if (window.self !== window.top) {
            const response = await safeSendMessage({ action: "GET_TOP_INFO" });
            if (response) { finalTitle = response.title; finalUrl = response.url; }
        }
        
        const currentInfo = await getVideoInfo(finalTitle, finalUrl);
        if (currentInfo.episode === "正片") return;
        
        safeStorageGet(['favorites'], (res) => {
            const favs = res.favorites || {};
            const record = favs[currentInfo.series];
            if (!record) return;
            const normRecordEp = normalizeEpisode(record.episode);
            const normCurrentEp = normalizeEpisode(currentInfo.episode);
            if (normRecordEp === normCurrentEp && record.time > 10) {
                if (Math.abs(video.currentTime - record.time) <= 15) return;
                jumpInProgress = true;
                video.currentTime = record.time;
                if (jumpTimeout) clearTimeout(jumpTimeout);
                jumpTimeout = setTimeout(() => {
                    if (!jumpCompleted) {
                        console.log("[追剧助手] 跳转超时，标记完成");
                        jumpCompleted = true;
                        jumpInProgress = false;
                    }
                }, 3000);
                const checkJump = () => {
                    if (Math.abs(video.currentTime - record.time) <= 2) {
                        isJumped = true;
                        jumpCompleted = true;
                        jumpInProgress = false;
                        showJumpTip(record.time);
                        console.log(`[追剧助手] 续播至 ${record.time}秒`);
                        video.removeEventListener('timeupdate', checkJump);
                        if (jumpTimeout) clearTimeout(jumpTimeout);
                    }
                };
                video.addEventListener('timeupdate', checkJump);
                setTimeout(() => {
                    if (!jumpCompleted && retryCount < 3) {
                        console.log(`[追剧助手] 跳转未生效，重试 ${retryCount+1}`);
                        autoJump(video, retryCount+1);
                    }
                }, 1000);
            }
        });
    }
    
    // ======================== 进度保存（降低门槛并增加日志） ========================
    async function updateProgress(video) {
        if (jumpInProgress && !jumpCompleted) return;
        // 降低门槛：duration >= 10 秒，currentTime >= 3 秒
        if (isNaN(video.duration) || video.duration < 10 || video.currentTime < 3) {
            console.log("[追剧助手] 视频时长过短或未就绪，跳过保存", video.duration, video.currentTime);
            return;
        }
        
        if (!config.autoUpdateFav) return;
        
        let finalUrl = window.location.href;
        let finalTitle = document.title;
        if (window.self !== window.top) {
            const response = await safeSendMessage({ action: "GET_TOP_INFO" });
            if (response) { finalTitle = response.title; finalUrl = response.url; }
        }
        
        const info = await getVideoInfo(finalTitle, finalUrl);
        if (info.episode === "正片") {
            console.log("[追剧助手] 未识别到集数，不保存");
            return;
        }
        
        console.log(`[追剧助手] 保存进度: ${info.series} ${info.episode} ${Math.floor(video.currentTime)}/${Math.floor(video.duration)}`);
        
        safeSendMessage({
            action: "UPDATE_FAV",
            data: {
                series: info.series,
                episode: info.episode,
                time: Math.floor(video.currentTime),
                duration: Math.floor(video.duration),
                url: finalUrl
            }
        });
    }
    
    // ======================== 新增：跳过片头片尾 & 自动下一集 ========================
    // 检测站点策略（用于下一集按钮选择器）
    function getSiteStrategy(url) {
        const strategies = [
            { domain: 'bilibili.com', name: 'B站', nextSelectors: ['.bpx-player-ctrl-next', '.squirtle-video-next', '.bilibili-player-video-btn-next', '[aria-label="下一个"]'] },
            { domain: 'youtube.com', name: 'YouTube', nextSelectors: ['.ytp-next-button', 'a[aria-label="Next"]'] },
            { domain: 'iqiyi.com', name: '爱奇艺', nextSelectors: ['.next-episode'] },
            { domain: 'v.qq.com', name: '腾讯', nextSelectors: ['.next_episode'] },
            { domain: 'youku.com', name: '优酷', nextSelectors: ['.next'] },
            { domain: 'mgtv.com', name: '芒果', nextSelectors: ['.next-episode'] }
        ];
        for (const s of strategies) {
            if (url.includes(s.domain)) return s;
        }
        return { name: '通用', nextSelectors: ['.next', '.nxt', '.switch-btn.next', '#multi_page .cur + li a'] };
    }
    
    // 尝试点击下一集按钮
    function tryClickNext() {
        const strategy = getSiteStrategy(window.location.href);
        for (const sel of strategy.nextSelectors) {
            const btn = document.querySelector(sel);
            if (btn && !btn.disabled) {
                btn.click();
                return true;
            }
        }
        return false;
    }
    
    // 从播放列表高亮跳转下一集（参考 skipEnd.js 的 skipDom 逻辑）
    function tryJumpFromPlaylist() {
        // 1. 查找所有 a 标签，寻找“下一集”文本或基于 active 类跳转
        const allLinks = document.querySelectorAll('a');
        let playNext = false;
        for (let i = 0; i < allLinks.length; i++) {
            const link = allLinks[i];
            const text = link.innerText.trim();
            if (text === "下一集") {
                link.click();
                return true;
            }
            if (text.indexOf("第") >= 0 && text.indexOf("集") >= 0) {
                if (playNext) {
                    link.click();
                    return true;
                }
                if (link.classList.contains('active') || (link.parentNode && link.parentNode.classList.contains('active'))) {
                    playNext = true;
                }
            }
        }
        // 2. 针对 .module-play-list-link 列表（常见影视站）
        const playlistItems = document.querySelectorAll('.module-play-list-link');
        if (playlistItems.length) {
            for (let i = 0; i < playlistItems.length; i++) {
                const item = playlistItems[i];
                if (item.classList.contains('active') && i < playlistItems.length - 1) {
                    playlistItems[i + 1].click();
                    return true;
                }
            }
        }
        return false;
    }
    
    // URL 数字递增跳转（参考 skipEnd.js 的 skipUrl）
    function tryUrlIncrement() {
        if (window.self !== window.top) return false; // 只在顶层页面执行
        const domains = config.urlIncrementDomains;
        let matched = false;
        for (const domain of domains) {
            if (window.location.href.indexOf(domain) >= 0) {
                matched = true;
                break;
            }
        }
        if (!matched) return false;
        const newUrl = window.location.href.replace(/(\d+)\.html$/, (match, num) => {
            const nextNum = parseInt(num, 10) + 1;
            return nextNum + ".html";
        });
        if (newUrl !== window.location.href) {
            location.href = newUrl;
            return true;
        }
        return false;
    }
    
    // 综合自动下一集调用
    function autoNextEpisode() {
        if (!config.autoPlayNext) return false;
        if (isSwitchingEpisode) return false;
        // 优先级：URL递增 > DOM点击按钮 > 播放列表跳转
        if (tryUrlIncrement()) {
            isSwitchingEpisode = true;
            showToast("🚀 自动跳转下一集 (URL)");
            return true;
        }
        if (tryClickNext()) {
            isSwitchingEpisode = true;
            showToast("🚀 自动播放下一集");
            return true;
        }
        if (tryJumpFromPlaylist()) {
            isSwitchingEpisode = true;
            showToast("🚀 自动跳转下一集");
            return true;
        }
        return false;
    }
    
    // 跳过片头、片尾、循环播放、自动下一集的核心逻辑
    function handleSkipAndNext(video) {
        const now = Date.now();
        if (now - lastCheckTime < 500) return;
        lastCheckTime = now;
        
        if (!config.autoSkipEnable) return;
        if (video.duration < config.minDuration) return;
        
        // 循环播放（autoRestart）
        if (config.autoRestart && !hasTriggeredRestart) {
            if (Date.now() - videoLoadStartTime < 4000) {
                const timeLeft = video.duration - video.currentTime;
                if (timeLeft < 30 || video.currentTime / video.duration > 0.95) {
                    const outroTriggerTime = video.duration - (config.enableOutro ? config.outroTime : 0);
                    let targetPos = config.enableIntro ? config.introTime : 0;
                    if (targetPos >= outroTriggerTime) targetPos = 0;
                    video.currentTime = targetPos;
                    showToast(`↺ 已重置到 ${targetPos}秒`);
                    hasTriggeredRestart = true;
                    hasSkippedIntro = true;
                    restartCooldownTime = Date.now() + 5000;
                    return;
                }
            }
        }
        
        // 片头跳过
        const introTime = config.introTime;
        const outroTime = config.outroTime;
        const outroTriggerTime = video.duration - (config.enableOutro ? outroTime : 0);
        const isOverlap = introTime >= outroTriggerTime;
        
        if (config.enableIntro && !isOverlap) {
            if (video.currentTime < introTime && !hasSkippedIntro && video.currentTime > 0.5) {
                if (Date.now() < restartCooldownTime) {
                    hasSkippedIntro = true;
                } else if (introTime < video.duration) {
                    video.currentTime = introTime;
                    hasSkippedIntro = true;
                    showToast(`🚀 跳过片头 (${introTime}秒)`);
                }
            }
        }
        
        // 片尾跳过 + 自动下一集
        if (config.enableOutro && outroTime > 0) {
            if (Date.now() < restartCooldownTime) return;
            if (video.currentTime > outroTriggerTime && video.currentTime < video.duration) {
                if (Date.now() - videoLoadStartTime < 4000 && !hasTriggeredRestart) return;
                if (isSwitchingEpisode) return;
                // 先尝试自动下一集
                if (config.autoPlayNext && autoNextEpisode()) {
                    return;
                }
                // 否则直接跳到片尾结束
                if (!isSwitchingEpisode) {
                    video.currentTime = video.duration;
                    showToast(`🚀 跳过片尾 (${outroTime}秒)`);
                }
            }
        }
    }
    
    // ======================== 站点预设自动匹配 ========================
    function checkAndApplyAutoMatch() {
        if (!config.autoApplyPreset) return;
        if (!config.savedPresets || config.savedPresets.length === 0) return;
        
        const currentUrl = window.location.href;
        const currentTitle = document.title;
        const matchedPreset = config.savedPresets.find(p => {
            if (!p.domain || p.domain.trim() === "") return false;
            return currentUrl.includes(p.domain) || currentTitle.includes(p.domain);
        });
        
        if (matchedPreset) {
            console.log("[追剧助手] 匹配预设方案:", matchedPreset.name);
            config.autoSkipEnable = true;
            config.introTime = matchedPreset.intro;
            config.outroTime = matchedPreset.outro;
            config.autoRestart = matchedPreset.restart;
            config.autoPlayNext = matchedPreset.next;
            config.enableIntro = (matchedPreset.intro > 0);
            config.enableOutro = (matchedPreset.outro > 0);
            chrome.storage.local.set({
                autoSkipEnable: true,
                introTime: matchedPreset.intro,
                outroTime: matchedPreset.outro,
                autoRestart: matchedPreset.restart,
                autoPlayNext: matchedPreset.next,
                enableIntro: (matchedPreset.intro > 0),
                enableOutro: (matchedPreset.outro > 0),
                lastActivePreset: matchedPreset.name
            });
            showToast(`⚡ 已激活方案: ${matchedPreset.name}`);
        } else if (config.autoSkipEnable === true) {
            console.log("[追剧助手] 无匹配方案，自动关闭跳过功能");
            config.autoSkipEnable = false;
            chrome.storage.local.set({ autoSkipEnable: false, lastActivePreset: "" });
        }
    }
    
    // ======================== 快捷键处理 ========================
    function isKeyMatch(event, keyConfig) {
        if (!keyConfig || !keyConfig.code) return false;
        if (event.code !== keyConfig.code) return false;
        if (event.shiftKey !== (keyConfig.shift || false)) return false;
        if (event.ctrlKey !== (keyConfig.ctrl || false)) return false;
        if (event.altKey !== (keyConfig.alt || false)) return false;
        return true;
    }
    
    function onKeyHandler(event) {
        const isForward = isKeyMatch(event, config.keyForward);
        const isRewind = isKeyMatch(event, config.keyRewind);
        if (!isForward && !isRewind) return;
        
        const video = findMainVideo();
        if (!video) return;
        const skipTime = config.manualSkipTime || 90;
        if (isForward) {
            video.currentTime += skipTime;
            showToast(`>>> 快进 ${skipTime} 秒`);
        } else if (isRewind) {
            video.currentTime -= skipTime;
            showToast(`<<< 快退 ${skipTime} 秒`);
        }
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
    }
    
    // ======================== 视频探测与绑定 ========================
    function findVideosInShadow(root = document) {
        let videos = Array.from(root.querySelectorAll('video'));
        const allNodes = root.querySelectorAll('*');
        for (const node of allNodes) {
            if (node.shadowRoot) {
                videos = videos.concat(findVideosInShadow(node.shadowRoot));
            }
        }
        return videos;
    }
    
    function findMainVideo() {
        const videos = findVideosInShadow(document);
        if (videos.length === 0) return null;
        if (videos.length === 1) return videos[0];
        const playingVideo = videos.find(v => !v.paused && v.duration > 10);
        if (playingVideo) return playingVideo;
        return videos.sort((a, b) => {
            let durA = isFinite(a.duration) ? a.duration : 0;
            let durB = isFinite(b.duration) ? b.duration : 0;
            return durB - durA;
        })[0];
    }
    
    function attachVideoListener(video) {
        if (boundVideos.has(video)) return;
        boundVideos.add(video);
        
        if (!video.dataset.hasSkipperListener) {
            // 时间更新：同步进度 + 跳过逻辑
            video.addEventListener('timeupdate', (e) => {
                updateProgress(video);
                handleSkipAndNext(video);
            });
            
            const resetState = () => {
                hasSkippedIntro = false;
                isSwitchingEpisode = false;
                hasTriggeredRestart = false;
                videoLoadStartTime = Date.now();
                restartCooldownTime = 0;
                lastCheckTime = 0;
                cachedTopTitle = null;
                cachedTopUrl = null;
                
                // 重新匹配预设方案
                setTimeout(checkAndApplyAutoMatch, 1000);
                // 重置续播标志（允许新视频续播）
                isJumped = false;
                jumpAttempted = false;
                jumpCompleted = false;
                jumpInProgress = false;
                if (jumpTimeout) clearTimeout(jumpTimeout);
                
                // 尝试自动续播
                setTimeout(() => {
                    if (!jumpAttempted) {
                        jumpAttempted = true;
                        autoJump(video);
                    }
                }, 500);
            };
            
            video.addEventListener('loadedmetadata', resetState);
            video.addEventListener('durationchange', resetState);
            video.addEventListener('emptied', resetState);
            video.addEventListener('seeking', () => {
                if (video.currentTime < 1) hasSkippedIntro = false;
            });
            
            videoLoadStartTime = Date.now();
            video.dataset.hasSkipperListener = 'true';
        }
    }
    
    function bindEvents() {
        const videos = findVideosInShadow(document);
        const mainVideo = videos.filter(v => !isNaN(v.duration) && v.duration > 30)
                                 .sort((a,b) => b.duration - a.duration)[0];
        if (mainVideo && !boundVideos.has(mainVideo)) {
            console.log("[追剧助手] 绑定视频事件");
            attachVideoListener(mainVideo);
        }
    }
    
    // ======================== SPA URL 变化监听 ========================
    setInterval(() => {
        if (window.location.href !== lastUrl) {
            lastUrl = window.location.href;
            console.log("[追剧助手] URL 变化，重置状态");
            // 重置跳过相关状态
            hasSkippedIntro = false;
            isSwitchingEpisode = false;
            hasTriggeredRestart = false;
            isJumped = false;
            jumpAttempted = false;
            jumpCompleted = false;
            jumpInProgress = false;
            if (jumpTimeout) clearTimeout(jumpTimeout);
            // 重新匹配预设
            checkAndApplyAutoMatch();
            // 重新绑定视频
            setTimeout(bindEvents, 500);
        }
    }, 2000);
    
    // ======================== 加载配置并启动 ========================
    function loadConfigAndStart() {
        chrome.storage.local.get(null, (items) => {
            // 合并配置
            config = { ...config, ...items };
            if (!config.keyForward || !config.keyForward.code) config.keyForward = { code: 'ArrowRight', shift: true, ctrl: false, alt: false };
            if (!config.keyRewind || !config.keyRewind.code) config.keyRewind = { code: 'ArrowLeft', shift: true, ctrl: false, alt: false };
            
            // 监听配置变化
            chrome.storage.onChanged.addListener((changes) => {
                for (let key in changes) {
                    if (config.hasOwnProperty(key)) {
                        config[key] = changes[key].newValue;
                    }
                }
            });
            
            // 初始匹配预设
            checkAndApplyAutoMatch();
            
            // 监听键盘
            window.addEventListener('keydown', onKeyHandler, true);
            
            // 开始监控视频
            bindEvents();
            const observer = new MutationObserver(() => bindEvents());
            observer.observe(document.documentElement, { childList: true, subtree: true });
            setTimeout(bindEvents, 2000);
        });
    }
    
    // 避免重复加载
    if (window.hasZhuiJuLoaded) return;
    window.hasZhuiJuLoaded = true;
    loadConfigAndStart();
})();