(function() {
    let lastUrl = window.location.href;
    const boundVideos = new WeakSet();
    let isJumped = false; 

    // --- 1. 标题清洗：增加 DOM 辅助识别 ---
    function cleanTitle(rawTitle) {
        if (!rawTitle) return { series: "未知视频", episode: "正片" };

        let title = rawTitle.trim();

        // 【新增 1.1】：针对泥视频等站点的 DOM 探测集数
        // 尝试从页面上的“选集列表”中直接寻找带有 active 或正在播放状态的文字
        let domEpisode = null;
        try {
            // 匹配泥视频的选集列表：类名为 module-play-list-link 且包含 active
            // 或者通用匹配常见的播放列表高亮项
            const activeEp = document.querySelector('.module-play-list-link.active, .video_item.active, .episodes-list .active, .player-list-item.active');
            if (activeEp) {
                domEpisode = activeEp.innerText.trim();
            }
        } catch (e) {}

        // 番号识别优先级最高
        const codeMatch = title.match(/[A-Z]{2,5}-\d{3,5}/i);
        if (codeMatch) {
            return { series: codeMatch[0].toUpperCase(), episode: "正片" };
        }

        // 常规清洗逻辑
        const bracketMatch = title.match(/《(.*?)》/);
        if (bracketMatch && bracketMatch[1]) {
            title = bracketMatch[1];
        }

        let episode = domEpisode || "正片"; // 如果 DOM 抓到了集数，优先使用
        
        // 如果 DOM 没抓到，再从标题里尝试正则提取
        const epMatch = title.match(/第\s*(\d+)\s*[集话]|Ep\.?\s*(\d+)|(P\d+)/i);
        if (epMatch && !domEpisode) {
            episode = epMatch[0];
            title = title.replace(epMatch[0], ""); 
        }

        const noiseWords = [
            /第[一二三四五六七八九十\d]+季/gi,
            /线上看|在线观看|免费|播放|线路|资源|下载|正片|完整版/gi,
            /1080P?|720P?|高清|4K|蓝光|BD|TC|超清/gi,
            /天天动漫|天天|樱花动漫|风车动漫|bilibili|哔哩哔哩|陌陌影视|AGE动漫|泥视频|nivod/gi,
            /粤语|国语|日语|中字|双语|外挂字幕/gi
        ];
        noiseWords.forEach(word => title = title.replace(word, ""));
        
        if (title.includes('-')) title = title.split('-')[0];
        if (title.includes('_')) title = title.split('_')[0];

        title = title.replace(/[()（）\[\]【】\s\-\|_—]/g, " ").trim();

        if (title.length > 15) {
            title = title.substring(0, 15) + "...";
        }
        
        // 泥视频修正：如果剧名抓到了“1集”，强行剔除（防止剧名被污染）
        title = title.replace(/\d+集$/, "").trim();

        return { series: title || "未知视频", episode: episode };
    }

    // --- 2. 核心逻辑：续播 ---
    async function autoJump(video) {
        if (isJumped) return;
        if (video.currentTime > 15) return;

        let finalTitle = document.title;
        if (window.self !== window.top) {
            const response = await chrome.runtime.sendMessage({ action: "GET_TOP_INFO" });
            if (response) finalTitle = response.title;
        }

        const currentInfo = cleanTitle(finalTitle);

        chrome.storage.local.get(['favorites'], (res) => {
            const favs = res.favorites || {};
            const record = favs[currentInfo.series];

            // 匹配条件：剧名+集数完全一致
            if (record && record.episode === currentInfo.episode && record.time > 10) {
                if (video.duration && record.time > video.duration - 10) return;

                video.currentTime = record.time;
                isJumped = true;
                showJumpTip(record.time);
            }
        });
    }

    // --- 3. 辅助功能 ---
    function findVideos(root) {
        let videos = Array.from(root.querySelectorAll('video'));
        root.querySelectorAll('*').forEach(el => {
            if (el.shadowRoot) videos = videos.concat(findVideos(el.shadowRoot));
        });
        return videos;
    }

    async function updateProgress(video) {
        // 过滤掉广告（时长太短）或还没开始播放的
        if (isNaN(video.duration) || video.duration < 30 || video.currentTime < 5) return;

        let finalUrl = window.location.href;
        let finalTitle = document.title;

        if (window.self !== window.top) {
            const response = await chrome.runtime.sendMessage({ action: "GET_TOP_INFO" });
            if (response) {
                finalTitle = response.title;
                finalUrl = response.url;
            }
        }

        const info = cleanTitle(finalTitle);
        
        // 调试用打印（发布时可注释）
        console.log(`[追剧助手] 上报进度: ${info.series} - ${info.episode} (${Math.floor(video.currentTime)}s)`);

        chrome.runtime.sendMessage({
            action: "UPDATE_FAV",
            data: {
                series: info.series,
                episode: info.episode,
                time: Math.floor(video.currentTime),
                duration: Math.floor(video.duration),
                url: finalUrl
            }
        });
    }

    // --- 4. 绑定事件 ---
    function bindEvents() {
        const videos = findVideos(document);
        // 筛选主视频
        const mainVideo = videos
            .filter(v => !isNaN(v.duration) && v.duration > 30)
            .sort((a, b) => b.duration - a.duration)[0];

        if (mainVideo && !boundVideos.has(mainVideo)) {
            if (mainVideo.readyState >= 1) {
                autoJump(mainVideo);
            } else {
                mainVideo.addEventListener('loadedmetadata', () => autoJump(mainVideo));
            }

            let lastUpdate = 0;
            mainVideo.addEventListener('timeupdate', () => {
                if (Date.now() - lastUpdate > 10000) { 
                    updateProgress(mainVideo);
                    lastUpdate = Date.now();
                }
            });
            boundVideos.add(mainVideo);
        }
    }

    function showJumpTip(totalSeconds) {
        const min = Math.floor(totalSeconds / 60);
        const sec = totalSeconds % 60;
        const tip = document.createElement('div');
        tip.innerHTML = `🎬 已为你续播到 ${min}分${sec}秒`;
        Object.assign(tip.style, {
            position: 'fixed', top: '25px', left: '50%', transform: 'translateX(-50%)',
            backgroundColor: 'rgba(0, 174, 236, 0.95)', color: 'white', padding: '10px 20px',
            borderRadius: '25px', zIndex: '2147483647', fontSize: '14px', fontWeight: 'bold',
            transition: 'all 0.5s', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', pointerEvents: 'none'
        });
        document.body.appendChild(tip);
        setTimeout(() => {
            tip.style.opacity = '0';
            tip.style.top = '15px';
            setTimeout(() => tip.remove(), 500);
        }, 3000);
    }

    // --- 5. 启动器 ---
    const observer = new MutationObserver(() => bindEvents());
    observer.observe(document.body, { childList: true, subtree: true });

    setInterval(() => {
        if (window.location.href !== lastUrl) {
            lastUrl = window.location.href;
            isJumped = false; 
            bindEvents();
        }
    }, 3000);

    setTimeout(bindEvents, 2000);
})();
