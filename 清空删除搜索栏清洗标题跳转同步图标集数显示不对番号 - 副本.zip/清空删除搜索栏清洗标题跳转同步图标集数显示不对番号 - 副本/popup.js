let favData = {};

// --- 1. 核心渲染函数 (逻辑保持不变) ---
function render(filter = '') {
    const list = document.getElementById('list');
    if (!list) return; // 容错处理

    const keys = Object.keys(favData)
        .filter(k => k.toLowerCase().includes(filter.toLowerCase()))
        .sort((a, b) => favData[b].ts - favData[a].ts);

    if (keys.length === 0) {
        list.innerHTML = `<div style="text-align:center;color:#999;margin-top:40px;font-size:13px;">${filter ? '无搜索结果' : '暂无记录，快去追剧吧~'}</div>`;
        return;
    }

    list.innerHTML = keys.map(k => {
        const item = favData[k];
        const prog = Math.floor((item.time / item.duration) * 100) || 0;
        const dateStr = new Date(item.ts).toLocaleDateString().slice(5);

        return `
            <div class="item">
                <a href="${item.url}" target="_blank" class="content">
                    <div class="title" title="${item.series}">${item.series}</div>
                    <div class="info">
                        <span class="ep-tag">${item.episode}</span>
                        <span class="prog-tag">进度 ${prog}%</span>
                        <span class="time-tag">${dateStr}</span>
                    </div>
                    <div class="prog-track">
                        <div class="prog-fill" style="width: ${prog}%"></div>
                    </div>
                </a>
                <span class="del-btn" data-key="${k}" title="删除此记录">×</span>
            </div>
        `;
    }).join('');

    document.querySelectorAll('.del-btn').forEach(b => {
        b.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const key = e.target.dataset.key;
            if(confirm(`确定删除《${key}》的观看记录吗？`)) {
                delete favData[key];
                chrome.storage.local.set({ favorites: favData }, () => {
                    const searchBox = document.getElementById('search');
                    render(searchBox ? searchBox.value : '');
                });
            }
        }
    });
}

// --- 2. WebDAV 请求工具 (保持不变) ---
async function davRequest(method, path = 'video_history.json', body = null) {
    const config = await chrome.storage.local.get(['davUrl', 'davUser', 'davPass']);
    if (!config.davUrl || !config.davUser || !config.davPass) throw new Error('同步配置不完整');

    const auth = btoa(`${config.davUser}:${config.davPass}`);
    const baseUrl = config.davUrl.endsWith('/') ? config.davUrl : config.davUrl + '/';
    
    const options = {
        method,
        headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
        }
    };
    if (body) options.body = JSON.stringify(body);

    const response = await fetch(baseUrl + path, options);
    if (!response.ok && method !== 'GET') throw new Error(`服务器返回: ${response.status}`);
    return response;
}

const updateStatus = (msg, color = '#888') => {
    const el = document.getElementById('dav-status');
    if (el) {
        el.innerText = msg;
        el.style.color = color;
    }
};

// --- 3. 事件监听 (修复报错的核心部分) ---

document.addEventListener('DOMContentLoaded', () => {

    // A. 初始化加载数据
    chrome.storage.local.get(['favorites', 'davUrl', 'davUser', 'davPass'], res => {
        favData = res.favorites || {};
        const davUrlInput = document.getElementById('dav-url');
        const davUserInput = document.getElementById('dav-user');
        const davPassInput = document.getElementById('dav-pass');

        if(davUrlInput) davUrlInput.value = res.davUrl || '';
        if(davUserInput) davUserInput.value = res.davUser || '';
        if(davPassInput) davPassInput.value = res.davPass || '';
        render();
    });

    // B. 安全绑定：搜索输入
    const searchInput = document.getElementById('search');
    if (searchInput) {
        searchInput.oninput = (e) => render(e.target.value);
    }

    // C. 安全绑定：清空按钮
    const clearBtn = document.getElementById('clear-btn');
    if (clearBtn) {
        clearBtn.onclick = () => {
            if(confirm('警告：这将清空本地所有观看记录！')) {
                favData = {};
                chrome.storage.local.set({ favorites: {} }, render);
            }
        };
    }

    // D. 安全绑定：WebDAV 测试连接
    const davTestBtn = document.getElementById('dav-test');
    if (davTestBtn) {
        davTestBtn.onclick = async () => {
            const config = {
                davUrl: document.getElementById('dav-url').value.trim(),
                davUser: document.getElementById('dav-user').value.trim(),
                davPass: document.getElementById('dav-pass').value.trim()
            };
            updateStatus('正在连接...', '#00aeec');
            try {
                await chrome.storage.local.set(config);
                const res = await davRequest('GET');
                if (res.status === 401) throw new Error('账号或密码错误');
                updateStatus('✅ 连接成功并已保存配置', '#52c41a');
            } catch (e) {
                updateStatus('❌ 失败: ' + e.message, '#ff4d4f');
            }
        };
    }

    // E. 安全绑定：WebDAV 上传
    const davUploadBtn = document.getElementById('dav-upload');
    if (davUploadBtn) {
        davUploadBtn.onclick = async () => {
            updateStatus('同步中...', '#00aeec');
            try {
                await davRequest('PUT', 'video_history.json', favData);
                updateStatus('⬆️ 云端备份完成', '#52c41a');
            } catch (e) {
                updateStatus('❌ 上传失败: ' + e.message, '#ff4d4f');
            }
        };
    }

    // F. 安全绑定：WebDAV 下载
    const davDownloadBtn = document.getElementById('dav-download');
    if (davDownloadBtn) {
        davDownloadBtn.onclick = async () => {
            updateStatus('获取数据中...', '#00aeec');
            try {
                const res = await davRequest('GET');
                if (res.status === 404) throw new Error('云端没有找到备份文件');
                const data = await res.json();
                
                if (confirm('下载的数据将覆盖本地记录，确定吗？')) {
                    favData = data;
                    await chrome.storage.local.set({ favorites: favData });
                    render();
                    updateStatus('⬇️ 云端数据已同步至本地', '#52c41a');
                }
            } catch (e) {
                updateStatus('❌ 下载失败: ' + e.message, '#ff4d4f');
            }
        };
    }
});
