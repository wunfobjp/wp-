/**
 * 追剧助手 - Background Service Worker (MV3)
 * 功能：
 * 1. 监听进度上报并写入 storage
 * 2. 协助 Iframe 获取父页面标题和 URL (解决跨域匹配问题)
 * 3. 管理图标状态反馈 (REC 角标)
 */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // --- 逻辑 1：处理进度上报 (UPDATE_FAV) ---
    if (request.action === "UPDATE_FAV") {
        const { series, data } = { 
            series: request.data.series, 
            data: request.data 
        };

        // 从存储中获取现有记录并合并
        chrome.storage.local.get(['favorites'], (res) => {
            let favs = res.favorites || {};
            
            // 以“剧名”作为唯一 Key 存储
            // 包含：episode(集数), time(进度), duration(总长), url(链接), ts(时间戳)
            favs[series] = {
                ...data,
                ts: Date.now() // 更新最后观看时间，用于 Popup 排序
            };

            chrome.storage.local.set({ favorites: favs }, () => {
                // 在当前标签页图标上显示 "REC" 提示，代表保存成功
                showBadge(sender.tab.id);
            });
        });
    }

    // --- 逻辑 2：解决跨域 Iframe 拿不到父页面标题的问题 (GET_TOP_INFO) ---
    if (request.action === "GET_TOP_INFO") {
        // sender.tab 包含了当前消息发出者所属的标签页信息
        if (sender.tab) {
            sendResponse({
                title: sender.tab.title,
                url: sender.tab.url
            });
        } else {
            sendResponse(null);
        }
    }

    // 返回 true 以支持异步 sendResponse
    return true; 
});

/**
 * 辅助函数：在扩展图标上显示短暂的 REC 状态
 */
function showBadge(tabId) {
    if (!tabId) return;

    // 设置角标文字和颜色
    chrome.action.setBadgeText({ text: "REC", tabId: tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#00aeec", tabId: tabId });

    // 2秒后清除
    setTimeout(() => {
        // 检查标签页是否还存在，防止报错
        chrome.tabs.get(tabId, (tab) => {
            if (!chrome.runtime.lastError && tab) {
                chrome.action.setBadgeText({ text: "", tabId: tabId });
            }
        });
    }, 2000);
}

// 插件安装或更新时的初始化
chrome.runtime.onInstalled.addListener(() => {
    console.log("追剧助手已就绪！");
});
