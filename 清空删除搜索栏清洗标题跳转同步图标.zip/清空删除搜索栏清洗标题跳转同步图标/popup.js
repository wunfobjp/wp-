let favData = {};

// --- 1. 核心渲染函数 ---
function render(filter = '') {
    const list = document.getElementById('list');
    const keys = Object.keys(favData)
        .filter(k => k.toLowerCase().includes(filter.toLowerCase()))
        .sort((a, b) => favData[b].ts - favData[a].ts);

    if (keys.length === 0) {
        list.innerHTML = `<div style="text-align:center;color:#999;margin-top:20px;">${filter ? '无搜索结果' : '暂无记录'}</div>`;
        return;
    }

    list.innerHTML = keys.map(k => {
        const item = favData[k];
        const prog = Math.floor((item.time / item.duration) * 100) || 0;
        return `
            <div class="item">
                <a href="${item.url}" target="_blank" class="content">
                    <div class="title" title="${item.series}">${item.series}</div>
                    <div class="info">${item.episode} - 进度: ${prog}%</div>
                </a>
                <span class="del-btn" data-key="${k}">×</span>
            </div>
        `;
    }).join('');

    // 绑定删除按钮
    document.querySelectorAll('.del-btn').forEach(b => {
        b.onclick = (e) => {
            const key = e.target.dataset.key;
            if(confirm(`确定删除《${key}》的记录吗？`)) {
                delete favData[key];
                chrome.storage.local.set({ favorites: favData }, render);
            }
        }
    });
}

// --- 2. WebDAV 请求工具 ---
async function davRequest(method, path = 'video_history.json', body = null) {
    const config = await chrome.storage.local.get(['davUrl', 'davUser', 'davPass']);
    if (!config.davUrl || !config.davUser || !config.davPass) throw new Error('配置不完整');

    const auth = btoa(`${config.davUser}:${config.davPass}`);
    const baseUrl = config.davUrl.endsWith('/') ? config.davUrl : config.davUrl + '/';
    
    const options = {
        method,
        headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
        }
    };
    if (body) options.body = JSON.stringify(body);

    const response = await fetch(baseUrl + path, options);
    if (!response.ok && method !== 'GET') throw new Error(`HTTP ${response.status}`);
    return response;
}

const updateStatus = (msg, color = '#888') => {
    const el = document.getElementById('dav-status');
    el.innerText = msg;
    el.style.color = color;
};

// --- 3. 事件监听 ---

// 初始化：加载数据和配置
chrome.storage.local.get(['favorites', 'davUrl', 'davUser', 'davPass'], res => {
    favData = res.favorites || {};
    document.getElementById('dav-url').value = res.davUrl || '';
    document.getElementById('dav-user').value = res.davUser || '';
    document.getElementById('dav-pass').value = res.davPass || '';
    render();
});

// 搜索
document.getElementById('search').oninput = (e) => render(e.target.value);

// 清空全部
document.getElementById('clear-btn').onclick = () => {
    if(confirm('确定清空所有记录？')) {
        favData = {};
        chrome.storage.local.set({ favorites: {} }, render);
    }
};

// WebDAV: 测试并保存
document.getElementById('dav-test').onclick = async () => {
    const config = {
        davUrl: document.getElementById('dav-url').value.trim(),
        davUser: document.getElementById('dav-user').value.trim(),
        davPass: document.getElementById('dav-pass').value.trim()
    };
    updateStatus('正在测试...', '#00aeec');
    try {
        await chrome.storage.local.set(config);
        // 通过 GET 请求测试连接（即使文件不存在 404 也说明连接通了）
        const res = await davRequest('GET');
        if (res.status === 401) throw new Error('账号或密码错误');
        updateStatus('✅ 连接成功并保存', '#52c41a');
    } catch (e) {
        updateStatus('❌ 失败: ' + e.message, '#ff4d4f');
    }
};

// WebDAV: 上传备份
document.getElementById('dav-upload').onclick = async () => {
    updateStatus('正在上传...', '#00aeec');
    try {
        await davRequest('PUT', 'video_history.json', favData);
        updateStatus('⬆️ 备份成功', '#52c41a');
    } catch (e) {
        updateStatus('❌ 上传失败: ' + e.message, '#ff4d4f');
    }
};

// WebDAV: 下载恢复
document.getElementById('dav-download').onclick = async () => {
    updateStatus('正在下载...', '#00aeec');
    try {
        const res = await davRequest('GET');
        if (res.status === 404) throw new Error('云端无备份');
        const data = await res.json();
        if (confirm('下载的数据将覆盖本地，确定吗？')) {
            favData = data;
            await chrome.storage.local.set({ favorites: favData });
            render();
            updateStatus('⬇️ 恢复成功', '#52c41a');
        }
    } catch (e) {
        updateStatus('❌ 下载失败: ' + e.message, '#ff4d4f');
    }
};
