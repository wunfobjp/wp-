(function() {
    let lastUrl = window.location.href;
    const boundVideos = new WeakSet();
    let isJumped = false; // 防止单次加载重复跳转

    // --- 1. 标题清洗：剔除干扰词，提取剧名和集数 ---
    function cleanTitle(rawTitle) {
        if (!rawTitle) return { series: "未知视频", episode: "正片" };

        let title = rawTitle;

        // A. 优先取书名号内的内容
        const bracketMatch = title.match(/《(.*?)》/);
        if (bracketMatch && bracketMatch[1]) {
            title = bracketMatch[1];
        }

        // B. 剔除关键词：包含第几季、线上看、站点名等
        const noiseWords = [
            /第[一二三四五六七八九十\d]+季/gi,
            /线上看|在线观看|免费|播放|线路|资源|下载|正片/gi,
            /1080P?|720P?|高清|4K|蓝光|BD|TC|超清/gi,
            /天天动漫|天天|樱花动漫|风车动漫|bilibili|哔哩哔哩|陌陌影视/gi,
            /粤语|国语|日语|中字|双语|外挂字幕/gi
        ];

        // C. 提取集数/话数 (如：第12集, Ep.05, P01)
        let episode = "正片";
        const epMatch = title.match(/第\s*(\d+)\s*[集话]|Ep\.?\s*(\d+)|(P\d+)/i);
        if (epMatch) {
            episode = epMatch[0];
            title = title.replace(epMatch[0], ""); 
        }

        // D. 清理干扰词和特殊符号
        noiseWords.forEach(word => title = title.replace(word, ""));
        
        // 针对 "剧名 - 后缀" 结构处理
        if (title.includes('-')) title = title.split('-')[0];
        if (title.includes('_')) title = title.split('_')[0];

        title = title.replace(/[()（）\[\]【】\s\-\|_—]/g, " ").trim();
        
        return { series: title || "未知视频", episode: episode };
    }

    // --- 2. 核心逻辑：自动跳转进度 (续播) ---
    async function autoJump(video) {
        if (isJumped) return;

        let finalTitle = document.title;
        // 如果在 Iframe 中，向 Background 请求父页面的真实标题
        if (window.self !== window.top) {
            const response = await chrome.runtime.sendMessage({ action: "GET_TOP_INFO" });
            if (response) finalTitle = response.title;
        }

        const currentInfo = cleanTitle(finalTitle);

        chrome.storage.local.get(['favorites'], (res) => {
            const favs = res.favorites || {};
            const record = favs[currentInfo.series];

            // 匹配条件：剧名相同 且 集数相同 且 记录时间大于10秒
            if (record && record.episode === currentInfo.episode && record.time > 10) {
                // 检查当前进度是否落后于记录（防止用户手动回拉被强制跳回）
                if (Math.abs(video.currentTime - record.time) > 15) {
                    video.currentTime = record.time;
                    isJumped = true;
                    showJumpTip(record.time);
                    console.log(`[追剧助手] 成功续播至: ${record.time}秒`);
                }
            }
        });
    }

    // 在页面顶部显示跳转成功的提示气泡
    function showJumpTip(totalSeconds) {
        const min = Math.floor(totalSeconds / 60);
        const sec = totalSeconds % 60;
        const tip = document.createElement('div');
        tip.innerHTML = `🎬 已为你续播到 ${min}分${sec}秒`;
        Object.assign(tip.style, {
            position: 'fixed', top: '25px', left: '50%', transform: 'translateX(-50%)',
            backgroundColor: 'rgba(0, 174, 236, 0.95)', color: 'white', padding: '10px 20px',
            borderRadius: '25px', zIndex: '2147483647', fontSize: '14px', fontWeight: 'bold',
            transition: 'all 0.5s', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', pointerEvents: 'none'
        });
        document.body.appendChild(tip);
        setTimeout(() => {
            tip.style.opacity = '0';
            tip.style.top = '15px';
            setTimeout(() => tip.remove(), 500);
        }, 3000);
    }

    // --- 3. 辅助功能：视频查找与上报 ---
    function findVideos(root) {
        let videos = Array.from(root.querySelectorAll('video'));
        root.querySelectorAll('*').forEach(el => {
            if (el.shadowRoot) videos = videos.concat(findVideos(el.shadowRoot));
        });
        return videos;
    }

    async function updateProgress(video) {
        if (isNaN(video.duration) || video.duration < 30 || video.currentTime < 5) return;

        let finalUrl = window.location.href;
        let finalTitle = document.title;

        if (window.self !== window.top) {
            const response = await chrome.runtime.sendMessage({ action: "GET_TOP_INFO" });
            if (response) {
                finalTitle = response.title;
                finalUrl = response.url;
            }
        }

        const info = cleanTitle(finalTitle);
        chrome.runtime.sendMessage({
            action: "UPDATE_FAV",
            data: {
                series: info.series,
                episode: info.episode,
                time: Math.floor(video.currentTime),
                duration: Math.floor(video.duration),
                url: finalUrl
            }
        });
    }

    // --- 4. 绑定事件 ---
    function bindEvents() {
        const videos = findVideos(document);
        // 筛选出最像正片的视频（时长 > 30s）
        const mainVideo = videos
            .filter(v => !isNaN(v.duration) && v.duration > 30)
            .sort((a, b) => b.duration - a.duration)[0];

        if (mainVideo && !boundVideos.has(mainVideo)) {
            // 尝试自动跳转进度
            // 有些播放器加载较慢，建议在元数据加载后尝试
            if (mainVideo.readyState >= 1) {
                autoJump(mainVideo);
            } else {
                mainVideo.addEventListener('loadedmetadata', () => autoJump(mainVideo));
            }

            // 循环监听进度更新
            let lastUpdate = 0;
            mainVideo.addEventListener('timeupdate', () => {
                if (Date.now() - lastUpdate > 10000) { // 10秒保存一次
                    updateProgress(mainVideo);
                    lastUpdate = Date.now();
                }
            });
            boundVideos.add(mainVideo);
        }
    }

    // --- 5. 启动器 ---
    const observer = new MutationObserver(() => bindEvents());
    observer.observe(document.body, { childList: true, subtree: true });

    setInterval(() => {
        if (window.location.href !== lastUrl) {
            lastUrl = window.location.href;
            isJumped = false; // 换集或换页后重置跳转状态
            bindEvents();
        }
    }, 3000);

    // 初次运行
    setTimeout(bindEvents, 2000);
})();
