(function() {
    let lastUrl = window.location.href;
    const boundVideos = new WeakSet();
    let isJumped = false;
    let jumpAttempted = false;
    let jumpCompleted = false;
    // 使用控制器管理跳转状态
    let jumpController = { active: false, abort: null, timeoutId: null };
    let progressUpdateTimer = null;

    // ========= 辅助函数：数字转中文数字（1~99） =========
    function numberToChinese(num) {
        const chineseNums = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
        if (num === 0) return '零';
        if (num <= 10) return chineseNums[num];
        if (num < 20) return '十' + (num % 10 === 0 ? '' : chineseNums[num % 10]);
        const tens = Math.floor(num / 10);
        const ones = num % 10;
        return chineseNums[tens] + '十' + (ones === 0 ? '' : chineseNums[ones]);
    }

    function chineseToNumber(chStr) {
        const chMap = { '一':1, '二':2, '三':3, '四':4, '五':5, '六':6, '七':7, '八':8, '九':9, '十':10 };
        if (chStr.length === 1) return chMap[chStr] || 0;
        if (chStr === '十') return 10;
        if (chStr.startsWith('十')) return 10 + (chMap[chStr[1]] || 0);
        if (chStr.endsWith('十')) return (chMap[chStr[0]] || 0) * 10;
        if (chStr.includes('十')) {
            const parts = chStr.split('十');
            const left = parts[0] ? chMap[parts[0]] : 1;
            const right = parts[1] ? chMap[parts[1]] : 0;
            return left * 10 + right;
        }
        return 0;
    }

    // ========= 安全调用扩展 API =========
    async function safeSendMessage(message) {
        if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) return null;
        try { return await chrome.runtime.sendMessage(message); } catch(e) { return null; }
    }

    function safeStorageGet(keys, callback) {
        if (!chrome || !chrome.storage || !chrome.storage.local) { callback({}); return; }
        chrome.storage.local.get(keys, callback);
    }

    // ========= 集数规范化 =========
    function normalizeEpisode(ep) {
        const match = ep.match(/\d+/);
        if (match) return `第${parseInt(match[0])}集`;
        return ep;
    }

    // ========= 从 URL 提取集数 =========
    function extractEpisodeFromURL(url) {
        if (!url) return null;
        function validNum(num) { let n = parseInt(num,10); return n>0 && n<=9999; }
        let match = url.match(/\/vod-play\/\d+-\d+-(\d+)\//);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/play\/\d+-(\d+)-(\d+)\.html/);
        if (match && validNum(match[2])) return `第${parseInt(match[2])}集`;
        match = url.match(/[?&]ep=第(\d+)集/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/vodplay\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/play\/\d+_(\d+)_(\d+)\.html/);
        if (match && validNum(match[2])) return `第${parseInt(match[2])}集`;
        match = url.match(/\/play\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/player\/vod\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        const patterns = [
            /[\/-](\d{1,4})(?:\/|$)/,
            /[?&]ep(?:isode)?=(\d{1,4})/i,
            /[\/-]ep(\d{1,4})/i,
            /[\/-]p(\d{1,4})/i,
        ];
        for (const pattern of patterns) {
            const m = url.match(pattern);
            if (m && validNum(m[1])) return `第${parseInt(m[1])}集`;
        }
        return null;
    }

    // ========= 从 DOM 同步提取集数（增强版） =========
    function tryExtractEpisodeFromDOM() {
        function validNum(num) { let n = parseInt(num,10); return n>0 && n<=9999; }
        
        // 通用文本匹配函数
        const extractFromText = (text) => {
            if (!text) return null;
            // 匹配 "第12集"、"第12话"、"第12期"、"EP12"、"ep12"、"12."
            let match = text.match(/(?:第\s*(\d+)\s*[集话期])|(?:[Ee][Pp]\s*(\d+))|(?:^(\d{1,3})\.)/);
            if (match) {
                let num = match[1] || match[2] || match[3];
                if (num && validNum(num)) return `第${parseInt(num)}集`;
            }
            // 纯数字（如 "12"）但需要排除过大的数字或干扰词
            match = text.match(/^\s*(\d{1,3})\s*$/);
            if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
            return null;
        };

        // 1. olevod.com
        const oleActiveLi = document.querySelector('li.active_s.active_b.active');
        if (oleActiveLi) {
            let title = oleActiveLi.getAttribute('title');
            if (title) {
                let ep = extractFromText(title);
                if (ep) return ep;
            }
            let text = oleActiveLi.innerText.trim();
            let ep = extractFromText(text);
            if (ep) return ep;
        }
        // 2. 4kvm.tv
        const activeEpisode = document.querySelector('.episode-link.bg-dark-700\\/60.text-white');
        if (activeEpisode) {
            let episodeNum = activeEpisode.getAttribute('data-episode');
            if (episodeNum && !isNaN(parseInt(episodeNum)) && parseInt(episodeNum) <= 9999) {
                return `第${parseInt(episodeNum)}集`;
            }
            const span = activeEpisode.querySelector('span');
            if (span && span.innerText) {
                let ep = extractFromText(span.innerText);
                if (ep) return ep;
            }
        }
        // 3. moovie.c2v2.com
        const moovieLink = document.querySelector('.ep-btn.active');
        if (moovieLink && moovieLink.innerText) {
            let ep = extractFromText(moovieLink.innerText);
            if (ep && !/线路|资源|播放|更新/.test(ep)) return ep;
        }
        // 4. hemayi
        const hemayiLink = document.querySelector('.stui-play__list li.active a');
        if (hemayiLink && hemayiLink.innerText) {
            let ep = extractFromText(hemayiLink.innerText);
            if (ep && !/线路|资源|播放|更新/.test(ep)) return ep;
        }
        // 5. ttdm6
        const ttdm6Link = document.querySelector('.module-play-list-link.active');
        if (ttdm6Link && ttdm6Link.innerText) {
            let ep = extractFromText(ttdm6Link.innerText);
            if (ep && !/线路|资源|播放|更新/.test(ep)) return ep;
        }
        // 6. 通用选择器
        const selectors = [
            '.play-item.cont.active li.active a', 'li.active a', 'li.on a',
            '.module-play-list-link.current', '.episode-item-active', '[aria-current="page"]',
            '.stui-play__list li.active a', '.playlist li.active a', '.ep-list li.active a',
            '.episode-item-active', '.active', '.on', '.current'
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText) {
                let ep = extractFromText(el.innerText);
                if (ep && !/线路|资源|播放|更新/.test(ep)) return ep;
            }
        }
        return null;
    }

    function waitForElement(selector, timeout = 10000, interval = 200) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el) return resolve(el);
                if (Date.now() - start >= timeout) return resolve(null);
                setTimeout(check, interval);
            };
            check();
        });
    }

    async function getEpisodeFromDOMWithRetry() {
        const url = window.location.href;
        if (url.match(/\/vod\/\d+\/$/)) {
            console.log("[追剧助手] ttdm6 详情页，等待播放列表...");
            const activeLink = await waitForElement('.module-play-list-link.active', 10000, 200);
            if (activeLink) {
                const text = activeLink.innerText.trim();
                let match = text.match(/(第\s*\d+\s*[集话期])|(\d+)\s*[集话期]?/);
                if (match) {
                    let ep = match[0];
                    if (/^\d+$/.test(ep)) ep = `第${parseInt(ep)}集`;
                    if (!/线路|资源|播放|更新/.test(ep)) return ep;
                }
            }
            return "正片";
        }
        let maxRetries = 5, delay = 300;
        if (url.includes('hemayi.com') || url.includes('4kvm.tv') || url.includes('beijingbaroque.com') || url.includes('yao-da.com') || url.includes('gangjuw.tv') || url.includes('olevod.com')) {
            maxRetries = 10; delay = 500;
        }
        for (let i = 0; i < maxRetries; i++) {
            const ep = tryExtractEpisodeFromDOM();
            if (ep) return ep;
            await new Promise(r => setTimeout(r, delay));
        }
        return "正片";
    }

    // ========= 剧名清洗（修复季数保留） =========
    function cleanSeriesName(rawTitle, url) {
        if (!rawTitle) return "未知视频";
        let titleTemp = rawTitle.trim();
        const codePattern = /\b(?:FC2|FC2-PPV|HEYZO|Caribbean|一本道|加勒比|天然むすめ|東京熱|Tokyo-Hot)[-_]?\d+/i;
        if (codePattern.test(titleTemp)) {
            let cleaned = titleTemp.replace(/第\d+集/g, '').trim();
            if (cleaned) return cleaned;
            return titleTemp;
        }
        let seasonText = '', langTag = "";
        const seasonPattern = /(?:第\s*(\d+)\s*季|第\s*([一二三四五六七八九十]+)\s*季|(\d+)\s*季|([一二三四五六七八九十]+)\s*季)/i;
        let match = titleTemp.match(seasonPattern);
        if (match) {
            let seasonNum = null;
            if (match[1]) seasonNum = parseInt(match[1],10);
            else if (match[2]) seasonNum = chineseToNumber(match[2]);
            else if (match[3]) seasonNum = parseInt(match[3],10);
            else if (match[4]) seasonNum = chineseToNumber(match[4]);
            if (seasonNum && seasonNum>=1 && seasonNum<=99) {
                const chineseSeason = numberToChinese(seasonNum);
                seasonText = `第${chineseSeason}季`;
                // 移除季数部分，保留其他文本
                titleTemp = titleTemp.replace(seasonPattern, '').trim();
            }
        }
        if (url.includes('keke1.app')) {
            try {
                const detailLink = document.querySelector('.detail-title a strong, .play-box-side-header .detail-title a strong, a[href^="/detail/"] strong');
                if (detailLink && detailLink.innerText) {
                    let series = detailLink.innerText.trim();
                    if (series) {
                        if (series.includes('第') && series.includes('季')) return series;
                        return series + seasonText;
                    }
                }
            } catch(e) {}
        }
        let title = titleTemp;
        if (url.includes('4kvm.tv') && title.includes(':')) title = title.split(':')[0];
        if (url.includes('gangjuw.tv')) { const idx = title.indexOf('第'); if(idx>0) title = title.substring(0,idx); }
        if (url.includes('olevod.com')) {
            const langMatch = title.match(/[【【](国语|粤语)[】】]/);
            if (langMatch) { langTag = langMatch[1]; title = title.replace(/[【【](?:国语|粤语)[】】]/g,'').trim(); }
            title = title.replace(/[【【][^】】]*[】】]/g,'').trim();
        }
        if (!langTag) { if(title.includes("粤语")) langTag="粤语"; else if(title.includes("国语")) langTag="国语"; }
        const tailNoise = /(\.com|\.app|\.net|\.cc|免费|爱看|在线|高清|完整|播放|正在|视频|官方|最新|频道|4k影视|4K影视|影视|可可影视|线上看|港剧网)/i;
        const tailMatch = title.match(tailNoise);
        if (tailMatch) title = title.substring(0, tailMatch.index);
        const bracketMatch = title.match(/《(.*?)》/);
        if (bracketMatch) title = bracketMatch[1];
        title = title.replace(/[《》()（）\[\]【】\s\-\|_—]/g, "").trim();
        const noiseWords = [
            /在线观看|免费播放|高清|完整版|正片|正在播放|正在|播放/gi,
            /电视剧|电影|动漫|综艺|机器人|ikanbot|可可影视|影牛|欧乐影院|olevod/gi,
            /粤语/g, /国语/g, /免费/g, /爱看/g, /4k影视|4K影视|影视/g, /\d{5,}/g
        ];
        noiseWords.forEach(word => title = title.replace(word, ""));
        let finalSeries = (title + langTag).trim();
        if (!finalSeries) finalSeries = "未知视频";
        // 将季数加在末尾（如果原始标题中没有季数）
        if (seasonText && !finalSeries.includes(seasonText)) finalSeries = finalSeries + seasonText;
        return finalSeries;
    }

    // ========= 统一获取剧名和集数 =========
    async function getVideoInfo(finalTitle, finalUrl) {
        let episode = extractEpisodeFromURL(finalUrl);
        if (!episode) episode = await getEpisodeFromDOMWithRetry();
        const series = cleanSeriesName(finalTitle, finalUrl);
        console.log(`[追剧助手] 剧名: ${series}, 集数: ${episode}`);
        return { series, episode };
    }

    // ========= 辅助：等待跳转完成 =========
    function waitForJumpComplete(video, targetTime, timeoutMs = 3000) {
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            const check = () => {
                if (Math.abs(video.currentTime - targetTime) <= 2) {
                    resolve();
                } else if (Date.now() - startTime >= timeoutMs) {
                    reject(new Error('跳转超时'));
                } else {
                    requestAnimationFrame(check);
                }
            };
            check();
        });
    }

    // ========= 自动续播（重构：无状态竞争） =========
    async function autoJump(video, retryCount = 0) {
        if (isJumped || jumpCompleted) return;
        if (jumpController.active) {
            console.log("[追剧助手] 跳转已在进行中，跳过");
            return;
        }
        if (video.currentTime > 15) return;

        let finalTitle = document.title;
        let finalUrl = window.location.href;
        if (window.self !== window.top) {
            const response = await safeSendMessage({ action: "GET_TOP_INFO" });
            if (response) { finalTitle = response.title; finalUrl = response.url; }
        }

        const currentInfo = await getVideoInfo(finalTitle, finalUrl);
        if (currentInfo.episode === "正片") return;

        // 从存储获取记录
        const getRecord = () => new Promise((resolve) => {
            safeStorageGet(['favorites'], (res) => {
                const favs = res.favorites || {};
                resolve(favs[currentInfo.series]);
            });
        });
        const record = await getRecord();
        if (!record) return;
        
        const normRecordEp = normalizeEpisode(record.episode);
        const normCurrentEp = normalizeEpisode(currentInfo.episode);
        if (normRecordEp !== normCurrentEp) return;
        if (record.time <= 10) return;
        if (Math.abs(video.currentTime - record.time) <= 15) return;

        // 开始跳转
        jumpController.active = true;
        if (jumpController.timeoutId) clearTimeout(jumpController.timeoutId);
        
        try {
            console.log(`[追剧助手] 尝试跳转到 ${record.time}s`);
            video.currentTime = record.time;
            await waitForJumpComplete(video, record.time, 5000);
            isJumped = true;
            jumpCompleted = true;
            showJumpTip(record.time);
            console.log(`[追剧助手] 续播成功至 ${record.time}秒`);
        } catch (err) {
            console.log(`[追剧助手] 跳转失败: ${err.message}`);
            if (retryCount < 3) {
                console.log(`[追剧助手] 重试 ${retryCount+1}`);
                setTimeout(() => autoJump(video, retryCount+1), 1000);
            }
        } finally {
            jumpController.active = false;
            if (jumpController.timeoutId) clearTimeout(jumpController.timeoutId);
        }
    }

    // ========= 进度同步（增加防抖，避免跳转期间保存） =========
    async function updateProgress(video) {
        if (jumpController.active || jumpCompleted === false && jumpController.active) return;
        if (isNaN(video.duration) || video.duration < 30 || video.currentTime < 5) return;

        let finalUrl = window.location.href;
        let finalTitle = document.title;
        if (window.self !== window.top) {
            const response = await safeSendMessage({ action: "GET_TOP_INFO" });
            if (response) { finalTitle = response.title; finalUrl = response.url; }
        }

        const info = await getVideoInfo(finalTitle, finalUrl);
        if (info.episode === "正片") return;

        safeSendMessage({
            action: "UPDATE_FAV",
            data: {
                series: info.series,
                episode: info.episode,
                time: Math.floor(video.currentTime),
                duration: Math.floor(video.duration),
                url: finalUrl
            }
        });
    }

    // ========= 视频探测与绑定 =========
    function findVideos(root) {
        let videos = Array.from(root.querySelectorAll('video'));
        root.querySelectorAll('*').forEach(el => {
            if (el.shadowRoot) videos = videos.concat(findVideos(el.shadowRoot));
        });
        return videos;
    }

    function bindEvents() {
        const videos = findVideos(document);
        const mainVideo = videos.filter(v => !isNaN(v.duration) && v.duration > 30)
                                 .sort((a,b) => b.duration - a.duration)[0];
        if (mainVideo && !boundVideos.has(mainVideo)) {
            console.log("[追剧助手] 绑定视频事件");
            const tryAutoJump = () => {
                if (!jumpAttempted) {
                    jumpAttempted = true;
                    autoJump(mainVideo);
                }
            };
            if (mainVideo.readyState >= 1) tryAutoJump();
            else {
                mainVideo.addEventListener('loadedmetadata', tryAutoJump);
                mainVideo.addEventListener('canplay', tryAutoJump);
            }
            let lastUpdate = 0;
            const throttledUpdate = () => {
                if (Date.now() - lastUpdate > 10000) {
                    updateProgress(mainVideo);
                    lastUpdate = Date.now();
                }
            };
            mainVideo.addEventListener('timeupdate', throttledUpdate);
            // 监听视频源变化（例如切换清晰度）
            const srcObserver = new MutationObserver(() => {
                if (mainVideo.src && !boundVideos.has(mainVideo)) {
                    // 重新绑定
                    boundVideos.delete(mainVideo);
                    bindEvents();
                }
            });
            srcObserver.observe(mainVideo, { attributes: true, attributeFilter: ['src'] });
            boundVideos.add(mainVideo);
        }
    }

    function showJumpTip(seconds) {
        const min = Math.floor(seconds/60), sec = seconds%60;
        const tip = document.createElement('div');
        tip.innerHTML = `🎬 已为你续播到 ${min}分${sec}秒`;
        Object.assign(tip.style, {
            position:'fixed', top:'35px', left:'50%', transform:'translateX(-50%)',
            backgroundColor:'rgba(0,174,236,0.95)', color:'white', padding:'10px 25px',
            borderRadius:'30px', zIndex:'2147483647', fontSize:'14px', fontWeight:'bold',
            boxShadow:'0 4px 15px rgba(0,0,0,0.2)', pointerEvents:'none'
        });
        document.body.appendChild(tip);
        setTimeout(() => { tip.style.opacity='0'; setTimeout(()=>tip.remove(),500); }, 3000);
    }

    // 监听URL变化重置状态
    setInterval(() => {
        if (window.location.href !== lastUrl) {
            lastUrl = window.location.href;
            isJumped = false;
            jumpAttempted = false;
            jumpCompleted = false;
            if (jumpController.active) {
                jumpController.active = false;
                if (jumpController.timeoutId) clearTimeout(jumpController.timeoutId);
            }
            bindEvents();
        }
    }, 2000);

    // 优化 MutationObserver：只监听 video 标签的添加，减少开销
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.addedNodes.length) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeName === 'VIDEO' || (node.querySelector && node.querySelector('video'))) {
                        bindEvents();
                        break;
                    }
                }
            }
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(bindEvents, 2000);
})();