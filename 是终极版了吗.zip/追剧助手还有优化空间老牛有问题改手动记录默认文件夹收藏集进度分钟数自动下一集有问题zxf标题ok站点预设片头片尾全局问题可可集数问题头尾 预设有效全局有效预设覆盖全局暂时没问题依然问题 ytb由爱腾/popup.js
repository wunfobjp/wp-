// popup.js - 追剧助手完整版（预设独立于全局开关）
let favData = {};
let collections = {};
let currentTab = 'history';

// 默认收藏夹名称（不可删除）
const DEFAULT_COLLECTION_NAME = '默认收藏夹';

// 全局配置（用于设置页面）
let currentConfig = {
    autoSkipEnable: false,
    enableIntro: true,
    enableOutro: true,
    autoRestart: false,
    autoPlayNext: false,
    introTime: 90,
    outroRemain: 0,
    manualSkipTime: 90,
    minDuration: 300,
    keyForward: { code: 'ArrowRight', shift: true, ctrl: false, alt: false },
    keyRewind: { code: 'ArrowLeft', shift: true, ctrl: false, alt: false },
    savedPresets: [],
    autoApplyPreset: true,
    urlIncrementDomains: [],
    customTagRules: [],
    customSeriesRules: [],
    onlySaveMaxEpisode: false
};

// ======================== 原有函数（观看记录、收藏夹等） ========================
function saveCollections() {
    chrome.storage.local.set({ collections: collections });
}

function saveFavorites(callback) {
    chrome.storage.local.set({ favorites: favData }, () => {
        if (callback) callback();
    });
}

function ensureDefaultCollection() {
    if (!collections[DEFAULT_COLLECTION_NAME]) {
        collections[DEFAULT_COLLECTION_NAME] = [];
        saveCollections();
    }
}

async function recordCurrentPage() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.url) {
            alert("无法获取当前页面信息");
            return;
        }
        let rawTitle = tab.title || "未命名页面";
        let url = tab.url;
        let series = rawTitle.replace(/[【】《》()（）\[\]]/g, '').trim();
        if (series.length > 40) series = series.substring(0, 40);
        let finalSeries = series;
        let counter = 1;
        while (favData[finalSeries]) {
            finalSeries = `${series} (${counter})`;
            counter++;
        }
        let episode = "正片";
        const epMatch = url.match(/[\/-](\d{1,3})(?:\.html|\/|$)/) || rawTitle.match(/第(\d{1,3})集/);
        if (epMatch && parseInt(epMatch[1]) > 0 && parseInt(epMatch[1]) < 1000) {
            episode = `第${parseInt(epMatch[1])}集`;
        }
        const newRecord = {
            series: finalSeries,
            episode: episode,
            time: 0,
            duration: 0,
            url: url,
            ts: Date.now()
        };
        favData[finalSeries] = newRecord;
        await saveFavorites();
        const searchBox = document.getElementById('search');
        render(searchBox ? searchBox.value : '');
        if (currentTab === 'favorites') renderCollections();
        alert(`已记录：${finalSeries} (${episode})`);
    } catch (err) {
        console.error("记录当前页失败", err);
        alert("记录失败，请确保扩展有tabs权限");
    }
}

function editRecord(key) {
    const record = favData[key];
    if (!record) return;
    const overlay = document.createElement('div');
    overlay.className = 'edit-modal-overlay';
    const modal = document.createElement('div');
    modal.className = 'edit-modal';
    modal.innerHTML = `
        <h4>✏️ 编辑记录</h4>
        <label>剧名</label>
        <input id="edit-series" type="text" value="${escapeHtml(record.series)}" placeholder="剧名">
        <label>集数</label>
        <input id="edit-episode" type="text" value="${escapeHtml(record.episode)}" placeholder="如: 第5集">
        <div class="info-text">原URL: ${record.url.length > 50 ? record.url.substring(0,50)+'…' : record.url}</div>
        <div class="info-text">进度: ${Math.floor(record.time/60)}分${record.time%60}秒 / 总长: ${Math.floor(record.duration/60)}分</div>
        <div>
            <button class="btn-save" id="save-edit">保存</button>
            <button class="btn-cancel" id="cancel-edit">取消</button>
        </div>
    `;
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    const seriesInput = modal.querySelector('#edit-series');
    const episodeInput = modal.querySelector('#edit-episode');
    const saveBtn = modal.querySelector('#save-edit');
    const cancelBtn = modal.querySelector('#cancel-edit');
    saveBtn.onclick = () => {
        let newSeries = seriesInput.value.trim();
        let newEpisode = episodeInput.value.trim();
        if (!newSeries) {
            alert("剧名不能为空");
            return;
        }
        if (!newEpisode) newEpisode = "正片";
        const oldKey = key;
        const newKey = newSeries;
        const isKeyChanged = (oldKey !== newKey);
        if (isKeyChanged && favData[newKey] && favData[newKey] !== favData[oldKey]) {
            if (!confirm(`剧名「${newSeries}」已存在记录，是否覆盖原记录？\n覆盖后原记录将被删除，当前记录的进度等信息会替换原记录。`)) {
                return;
            }
            delete favData[newKey];
            for (let folder in collections) {
                const idx = collections[folder].indexOf(newKey);
                if (idx !== -1) collections[folder].splice(idx, 1);
            }
        }
        const updatedRecord = {
            ...favData[oldKey],
            series: newSeries,
            episode: newEpisode,
            ts: Date.now()
        };
        if (isKeyChanged) {
            delete favData[oldKey];
            favData[newSeries] = updatedRecord;
            for (let folder in collections) {
                const idx = collections[folder].indexOf(oldKey);
                if (idx !== -1) {
                    collections[folder][idx] = newSeries;
                    collections[folder] = [...new Set(collections[folder])];
                }
            }
        } else {
            favData[oldKey] = updatedRecord;
        }
        saveFavorites(() => {
            saveCollections();
            const searchBox = document.getElementById('search');
            render(searchBox ? searchBox.value : '');
            renderCollections();
            overlay.remove();
        });
    };
    cancelBtn.onclick = () => overlay.remove();
}

function renderCollections() {
    const container = document.getElementById('collections-list');
    if (!container) return;
    ensureDefaultCollection();
    const folderNames = Object.keys(collections).sort((a, b) => {
        if (a === DEFAULT_COLLECTION_NAME) return -1;
        if (b === DEFAULT_COLLECTION_NAME) return 1;
        return a.localeCompare(b);
    });
    if (folderNames.length === 0) {
        container.innerHTML = `<div style="text-align:center;color:#999;margin-top:40px;font-size:13px;">暂无收藏夹，点击下方按钮创建</div>`;
        return;
    }
    let html = '';
    for (const folderName of folderNames) {
        const seriesKeys = collections[folderName] || [];
        const itemsHtml = seriesKeys.map(key => {
            const record = favData[key];
            const title = record ? `${record.series} (${record.episode})` : key;
            const url = record ? record.url : '#';
            let progressText = '';
            if (record && record.duration && record.duration > 0) {
                const currentMin = Math.floor(record.time / 60);
                const totalMin = Math.floor(record.duration / 60);
                progressText = `<span style="font-size:10px; color:#888; margin-left:8px;">${currentMin}/${totalMin} 分钟</span>`;
            } else if (record && record.time > 0) {
                progressText = `<span style="font-size:10px; color:#888; margin-left:8px;">已看${Math.floor(record.time/60)}分</span>`;
            }
            return `
                <div class="folder-item">
                    <a href="${url}" target="_blank" class="folder-item-title" title="${escapeHtml(title)}">
                        ${escapeHtml(title)}${progressText}
                    </a>
                    <span class="remove-fav-btn" data-folder="${folderName}" data-key="${key}">✖</span>
                </div>
            `;
        }).join('') || '<div class="empty-folder">暂无剧集</div>';
        const isDefault = (folderName === DEFAULT_COLLECTION_NAME);
        const deleteButtonHtml = isDefault ? 
            '<span title="默认收藏夹不可删除" style="color:#ccc; cursor:not-allowed;">🗑️</span>' : 
            `<span class="delete-folder" data-folder="${folderName}" title="删除文件夹">🗑️</span>`;
        html += `
            <div class="folder" data-folder="${folderName}">
                <div class="folder-header">
                    <span class="folder-name">📁 ${escapeHtml(folderName)}${isDefault ? ' 🔒' : ''}</span>
                    <div class="folder-actions">
                        ${deleteButtonHtml}
                        <span class="toggle-folder" data-folder="${folderName}">▼</span>
                    </div>
                </div>
                <div class="folder-content">${itemsHtml}</div>
            </div>
        `;
    }
    container.innerHTML = html;
    document.querySelectorAll('.delete-folder').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const folder = btn.dataset.folder;
            if (folder === DEFAULT_COLLECTION_NAME) {
                alert('默认收藏夹不可删除');
                return;
            }
            if (confirm(`确定删除文件夹「${folder}」及其中的所有剧集吗？`)) {
                delete collections[folder];
                saveCollections();
                renderCollections();
                if (currentTab === 'history') {
                    const searchBox = document.getElementById('search');
                    render(searchBox ? searchBox.value : '');
                }
            }
        };
    });
    document.querySelectorAll('.toggle-folder').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const folder = btn.closest('.folder');
            const content = folder.querySelector('.folder-content');
            content.classList.toggle('open');
            btn.textContent = content.classList.contains('open') ? '▲' : '▼';
        };
    });
    document.querySelectorAll('.remove-fav-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const folder = btn.dataset.folder;
            const key = btn.dataset.key;
            if (collections[folder]) {
                collections[folder] = collections[folder].filter(k => k !== key);
                saveCollections();
                renderCollections();
                if (currentTab === 'history') {
                    const searchBox = document.getElementById('search');
                    render(searchBox ? searchBox.value : '');
                }
            }
        };
    });
}

function showFolderSelector(seriesKey, seriesTitle, callback) {
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
    overlay.style.zIndex = '10000';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    const dialog = document.createElement('div');
    dialog.style.backgroundColor = '#fff';
    dialog.style.borderRadius = '8px';
    dialog.style.padding = '20px';
    dialog.style.width = '280px';
    dialog.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    const titleEl = document.createElement('div');
    titleEl.textContent = `添加到收藏夹：${seriesTitle}`;
    titleEl.style.fontWeight = 'bold';
    titleEl.style.marginBottom = '12px';
    titleEl.style.fontSize = '14px';
    const select = document.createElement('select');
    select.style.width = '100%';
    select.style.padding = '8px';
    select.style.marginBottom = '12px';
    select.style.borderRadius = '4px';
    select.style.border = '1px solid #ddd';
    const folderNames = Object.keys(collections);
    if (folderNames.length === 0) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '暂无文件夹，请先新建';
        select.appendChild(option);
    } else {
        folderNames.forEach(folder => {
            const option = document.createElement('option');
            option.value = folder;
            option.textContent = folder;
            select.appendChild(option);
        });
    }
    const newFolderBtn = document.createElement('button');
    newFolderBtn.textContent = '新建文件夹';
    newFolderBtn.style.backgroundColor = '#00aeec';
    newFolderBtn.style.color = '#fff';
    newFolderBtn.style.border = 'none';
    newFolderBtn.style.padding = '8px';
    newFolderBtn.style.borderRadius = '4px';
    newFolderBtn.style.width = '100%';
    newFolderBtn.style.marginBottom = '12px';
    newFolderBtn.style.cursor = 'pointer';
    const confirmBtn = document.createElement('button');
    confirmBtn.textContent = '确认';
    confirmBtn.style.backgroundColor = '#52c41a';
    confirmBtn.style.color = '#fff';
    confirmBtn.style.border = 'none';
    confirmBtn.style.padding = '8px';
    confirmBtn.style.borderRadius = '4px';
    confirmBtn.style.width = '48%';
    confirmBtn.style.cursor = 'pointer';
    confirmBtn.style.marginRight = '4%';
    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = '取消';
    cancelBtn.style.backgroundColor = '#ddd';
    cancelBtn.style.color = '#333';
    cancelBtn.style.border = 'none';
    cancelBtn.style.padding = '8px';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.width = '48%';
    cancelBtn.style.cursor = 'pointer';
    const btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.justifyContent = 'space-between';
    btnContainer.appendChild(confirmBtn);
    btnContainer.appendChild(cancelBtn);
    dialog.appendChild(titleEl);
    dialog.appendChild(select);
    dialog.appendChild(newFolderBtn);
    dialog.appendChild(btnContainer);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    newFolderBtn.onclick = () => {
        let newFolderName = prompt('请输入新文件夹名称：');
        if (!newFolderName) return;
        if (newFolderName === DEFAULT_COLLECTION_NAME) {
            alert(`不能创建与默认收藏夹同名的文件夹`);
            return;
        }
        if (!collections[newFolderName]) {
            collections[newFolderName] = [];
            saveCollections();
            const option = document.createElement('option');
            option.value = newFolderName;
            option.textContent = newFolderName;
            select.appendChild(option);
            select.value = newFolderName;
            renderCollections();
        } else if (collections[newFolderName]) {
            alert('文件夹已存在');
        }
    };
    confirmBtn.onclick = () => {
        const selectedFolder = select.value;
        if (!selectedFolder) {
            alert('请选择或新建文件夹');
            return;
        }
        if (!collections[selectedFolder]) {
            collections[selectedFolder] = [];
        }
        if (!collections[selectedFolder].includes(seriesKey)) {
            collections[selectedFolder].push(seriesKey);
            saveCollections();
            alert(`已添加《${seriesTitle}》到「${selectedFolder}」`);
            renderCollections();
            if (currentTab === 'history') {
                const searchBox = document.getElementById('search');
                render(searchBox ? searchBox.value : '');
            } else {
                render();
            }
        } else {
            alert('该剧集已在当前文件夹中');
        }
        overlay.remove();
        if (callback) callback();
    };
    cancelBtn.onclick = () => {
        overlay.remove();
        if (callback) callback();
    };
}

function addToCollection(seriesKey, seriesTitle) {
    showFolderSelector(seriesKey, seriesTitle);
}

function isInAnyCollection(seriesKey) {
    for (const folder in collections) {
        if (collections[folder].includes(seriesKey)) return true;
    }
    return false;
}

function render(filter = '') {
    const list = document.getElementById('list');
    if (!list) return;
    const keys = Object.keys(favData)
        .filter(k => k.toLowerCase().includes(filter.toLowerCase()))
        .sort((a, b) => favData[b].ts - favData[a].ts);
    if (keys.length === 0) {
        list.innerHTML = `<div style="text-align:center;color:#999;margin-top:40px;font-size:13px;">${filter ? '无搜索结果' : '暂无记录，快去追剧吧~'}</div>`;
        return;
    }
    list.innerHTML = keys.map(k => {
        const item = favData[k];
        let prog = 0;
        if (item.duration && item.duration > 0) {
            prog = Math.floor((item.time / item.duration) * 100);
        }
        const dateStr = new Date(item.ts).toLocaleDateString().slice(5);
        const isFav = isInAnyCollection(k);
        return `
            <div class="item">
                <a href="${item.url}" target="_blank" class="content">
                    <div class="title" title="${escapeHtml(item.series)}">${escapeHtml(item.series)}</div>
                    <div class="info">
                        <span class="ep-tag">${escapeHtml(item.episode)}</span>
                        <span class="prog-tag">进度 ${prog}%</span>
                        <span class="time-tag">${dateStr}</span>
                    </div>
                    <div class="prog-track">
                        <div class="prog-fill" style="width: ${prog}%"></div>
                    </div>
                </a>
                <div class="item-actions">
                    <span class="edit-btn" data-key="${k}" title="编辑标题/集数">✏️</span>
                    <span class="fav-btn" data-key="${k}" data-title="${escapeHtml(item.series)}" title="${isFav ? '已收藏' : '添加到收藏夹'}">${isFav ? '⭐' : '☆'}</span>
                    <span class="del-btn" data-key="${k}" title="删除此记录">×</span>
                </div>
            </div>
        `;
    }).join('');
    document.querySelectorAll('.del-btn').forEach(b => {
        b.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const key = b.dataset.key;
            if (confirm(`确定删除《${favData[key]?.series || key}》的观看记录吗？`)) {
                delete favData[key];
                saveFavorites(() => {
                    const searchBox = document.getElementById('search');
                    render(searchBox ? searchBox.value : '');
                    renderCollections();
                });
            }
        };
    });
    document.querySelectorAll('.fav-btn').forEach(b => {
        b.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const key = b.dataset.key;
            const title = b.dataset.title;
            if (isInAnyCollection(key)) {
                if (confirm(`是否从收藏夹中移除《${title}》？`)) {
                    for (const folder in collections) {
                        const idx = collections[folder].indexOf(key);
                        if (idx !== -1) {
                            collections[folder].splice(idx, 1);
                            break;
                        }
                    }
                    saveCollections();
                    render();
                    renderCollections();
                }
            } else {
                addToCollection(key, title);
            }
        };
    });
    document.querySelectorAll('.edit-btn').forEach(b => {
        b.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const key = b.dataset.key;
            editRecord(key);
        };
    });
}

async function davRequest(method, path = 'video_history.json', body = null, retryMkcol = true) {
    const config = await chrome.storage.local.get(['davUrl', 'davUser', 'davPass']);
    if (!config.davUrl || !config.davUser || !config.davPass) throw new Error('同步配置不完整');
    const auth = btoa(`${config.davUser}:${config.davPass}`);
    let baseUrl = config.davUrl.endsWith('/') ? config.davUrl : config.davUrl + '/';
    if (path.startsWith('/')) path = path.substring(1);
    const fullUrl = baseUrl + path;
    const options = {
        method,
        headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
        }
    };
    if (body) options.body = JSON.stringify(body);
    const response = await fetch(fullUrl, options);
    if (method === 'PUT' && response.status === 409 && retryMkcol) {
        const dirPath = path.substring(0, path.lastIndexOf('/'));
        if (dirPath) {
            await davRequest('MKCOL', dirPath, null, false);
            return davRequest(method, path, body, false);
        }
    }
    if (!response.ok && method !== 'GET') throw new Error(`服务器返回: ${response.status}`);
    return response;
}

const updateStatus = (msg, color = '#888') => {
    const el = document.getElementById('dav-status');
    if (el) {
        el.innerText = msg;
        el.style.color = color;
    }
};

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function switchTab(tabId) {
    currentTab = tabId;
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabId);
    });
    document.getElementById('history-tab').classList.toggle('active', tabId === 'history');
    document.getElementById('favorites-tab').classList.toggle('active', tabId === 'favorites');
    document.getElementById('settings-tab').classList.toggle('active', tabId === 'settings');
    if (tabId === 'favorites') renderCollections();
    else if (tabId === 'history') {
        const searchBox = document.getElementById('search');
        render(searchBox ? searchBox.value : '');
    } else if (tabId === 'settings') {
        loadSettingsToForm();
        refreshVideoProgress();
        updatePresetPreview();
        renderPresetsList();
    }
}

function createNewFolder() {
    let folderName = prompt('请输入文件夹名称：');
    if (!folderName) return;
    if (folderName === DEFAULT_COLLECTION_NAME) {
        alert(`不能创建与默认收藏夹同名的文件夹`);
        return;
    }
    if (collections[folderName]) {
        alert('文件夹已存在');
        return;
    }
    collections[folderName] = [];
    saveCollections();
    renderCollections();
}

// ======================== 剧集预设快速设置相关函数 ========================
async function getCurrentMatchKey() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return null;
    const url = tab.url;
    let match = url.match(/\/play\/(\d+)/);
    if (match) return `/play/${match[1]}`;
    match = url.match(/\/cid\/(\d+)/);
    if (match) return `/cid/${match[1]}`;
    match = url.match(/\/vod\/(\d+)/);
    if (match) return `/vod/${match[1]}`;
    return new URL(url).hostname;
}

async function getCurrentVideoProgress() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return null;
    try {
        const response = await chrome.tabs.sendMessage(tab.id, { action: "GET_VIDEO_PROGRESS" });
        return response;
    } catch (e) {
        console.log("无法获取视频进度", e);
        return null;
    }
}

function formatTime(seconds) {
    if (!seconds || isNaN(seconds)) return "--:--";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

async function getCurrentSitePreset() {
    const matchKey = await getCurrentMatchKey();
    if (!matchKey) return null;
    const presets = currentConfig.savedPresets || [];
    return presets.find(p => p.matchKey === matchKey) || null;
}

async function updatePresetPreview() {
    const preset = await getCurrentSitePreset();
    const introSpan = document.getElementById('introPreview');
    const outroSpan = document.getElementById('outroPreview');
    if (introSpan) {
        const intro = preset ? preset.intro : 0;
        introSpan.innerText = `${Math.floor(intro / 60)}分${intro % 60}秒`;
    }
    if (outroSpan) {
        const outroRemain = preset ? preset.outroRemain : 0;
        outroSpan.innerText = `${Math.floor(outroRemain / 60)}分${outroRemain % 60}秒`;
    }
}

async function saveCurrentSitePreset(introTime, outroRemain) {
    const matchKey = await getCurrentMatchKey();
    if (!matchKey) return;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const title = tab.title;
    let presets = currentConfig.savedPresets || [];
    let existing = presets.find(p => p.matchKey === matchKey);
    
    if (introTime !== undefined) introTime = Math.min(600, Math.max(0, introTime));
    if (outroRemain !== undefined) outroRemain = Math.min(600, Math.max(0, outroRemain));
    
    if (existing) {
        if (introTime !== undefined) existing.intro = introTime;
        if (outroRemain !== undefined) existing.outroRemain = outroRemain;
    } else {
        presets.push({
            name: title.substring(0, 30),
            matchKey: matchKey,
            intro: introTime !== undefined ? introTime : 0,
            outroRemain: outroRemain !== undefined ? outroRemain : 0,
            restart: false,
            next: false
        });
    }
    currentConfig.savedPresets = presets;
    await chrome.storage.local.set({ savedPresets: presets });
    updatePresetPreview();
    renderPresetsList();
    const statusDiv = document.getElementById('settingsStatus');
    if (statusDiv) {
        statusDiv.innerHTML = '<span style="color:#52c41a;">✅ 剧集预设已更新</span>';
        setTimeout(() => {
            statusDiv.innerHTML = '';
        }, 1500);
    }
}

async function refreshVideoProgress() {
    const progress = await getCurrentVideoProgress();
    const currentSpan = document.getElementById('currentTimeDisplay');
    const durationSpan = document.getElementById('durationDisplay');
    if (currentSpan && durationSpan) {
        if (progress && !progress.error) {
            currentSpan.innerText = formatTime(progress.currentTime);
            durationSpan.innerText = formatTime(progress.duration);
        } else {
            currentSpan.innerText = "--:--";
            durationSpan.innerText = "--:--";
        }
    }
}

async function setIntroFromCurrent() {
    const progress = await getCurrentVideoProgress();
    if (progress && !progress.error) {
        const introTime = Math.floor(progress.currentTime);
        await saveCurrentSitePreset(introTime, undefined);
        currentConfig.introTime = introTime;
        await chrome.storage.local.set({ introTime: introTime });
        const introInput = document.getElementById('introTime');
        if (introInput) introInput.value = introTime;
        showToast(`片头已设为 ${Math.floor(introTime/60)}分${introTime%60}秒`);
    } else {
        alert("无法获取当前视频进度，请确保页面有正在播放的视频");
    }
}

async function setOutroFromCurrent() {
    const progress = await getCurrentVideoProgress();
    if (progress && !progress.error) {
        const duration = progress.duration;
        const current = progress.currentTime;
        let outroRemain = Math.floor(duration - current);
        if (outroRemain < 0) outroRemain = 0;
        await saveCurrentSitePreset(undefined, outroRemain);
        currentConfig.outroRemain = outroRemain;
        await chrome.storage.local.set({ outroRemain: outroRemain });
        const outroInput = document.getElementById('outroTime');
        if (outroInput) outroInput.value = outroRemain;
        showToast(`片尾已设为距结束 ${Math.floor(outroRemain/60)}分${outroRemain%60}秒`);
    } else {
        alert("无法获取当前视频进度，请确保页面有正在播放的视频");
    }
}

function renderPresetsList() {
    const container = document.getElementById('presetsList');
    if (!container) return;
    const presets = currentConfig.savedPresets || [];
    if (presets.length === 0) {
        container.innerHTML = '<div style="text-align:center;color:#999;padding:8px;">暂无预设方案</div>';
        return;
    }
    let html = '';
    for (let i = 0; i < presets.length; i++) {
        const p = presets[i];
        html += `
            <div class="preset-item">
                <div class="info" title="${escapeHtml(p.matchKey)}">
                    📌 ${escapeHtml(p.name || p.matchKey)}
                    <span style="color:#888; font-size:10px;"> (片头:${p.intro}s 片尾剩余:${p.outroRemain}s)</span>
                </div>
                <button class="delete-preset-btn" data-index="${i}">删除</button>
            </div>
        `;
    }
    container.innerHTML = html;
    document.querySelectorAll('.delete-preset-btn').forEach(btn => {
        btn.onclick = async () => {
            const idx = parseInt(btn.dataset.index, 10);
            if (confirm('确定删除该预设方案吗？')) {
                let presets = currentConfig.savedPresets || [];
                presets.splice(idx, 1);
                currentConfig.savedPresets = presets;
                await chrome.storage.local.set({ savedPresets: presets });
                renderPresetsList();
                const currentMatchKey = await getCurrentMatchKey();
                const stillExists = presets.some(p => p.matchKey === currentMatchKey);
                if (!stillExists) {
                    currentConfig.introTime = 0;
                    currentConfig.outroRemain = 0;
                    await chrome.storage.local.set({ introTime: 0, outroRemain: 0 });
                    loadSettingsToForm();
                }
                updatePresetPreview();
                const statusDiv = document.getElementById('settingsStatus');
                statusDiv.innerHTML = '<span style="color:#52c41a;">✅ 预设已删除</span>';
                setTimeout(() => statusDiv.innerHTML = '', 1500);
            }
        };
    });
}

// ======================== 设置页面表单加载与保存 ========================
function loadSettingsToForm() {
    document.getElementById('autoSkipEnable').checked = currentConfig.autoSkipEnable;
    document.getElementById('introTime').value = currentConfig.introTime;
    document.getElementById('outroTime').value = currentConfig.outroRemain;
    document.getElementById('autoRestart').checked = currentConfig.autoRestart;
    document.getElementById('autoPlayNext').checked = currentConfig.autoPlayNext;
    document.getElementById('minDuration').value = currentConfig.minDuration;
    document.getElementById('manualSkipTime').value = currentConfig.manualSkipTime;
    document.getElementById('forwardKeyDisplay').innerText = keyConfigToText(currentConfig.keyForward);
    document.getElementById('rewindKeyDisplay').innerText = keyConfigToText(currentConfig.keyRewind);
    const statusSpan = document.getElementById('settingsStatus');
    if (currentConfig.autoSkipEnable) {
        statusSpan.innerHTML = '<span class="status-badge status-enabled">✅ 状态: 已启用</span>';
    } else {
        statusSpan.innerHTML = '<span class="status-badge status-disabled">⛔ 状态: 已停用</span>';
    }
    renderPresetsList();
}

function saveSettings() {
    const newConfig = {
        ...currentConfig,
        autoSkipEnable: document.getElementById('autoSkipEnable').checked,
        introTime: parseInt(document.getElementById('introTime').value, 10) || 0,
        outroRemain: parseInt(document.getElementById('outroTime').value, 10) || 0,
        autoRestart: document.getElementById('autoRestart').checked,
        autoPlayNext: document.getElementById('autoPlayNext').checked,
        minDuration: parseInt(document.getElementById('minDuration').value, 10) || 0,
        manualSkipTime: parseInt(document.getElementById('manualSkipTime').value, 10) || 90,
        keyForward: currentConfig.keyForward,
        keyRewind: currentConfig.keyRewind
    };
    if (newConfig.introTime < 0) newConfig.introTime = 0;
    if (newConfig.outroRemain < 0) newConfig.outroRemain = 0;
    if (newConfig.minDuration < 0) newConfig.minDuration = 0;
    if (newConfig.manualSkipTime < 1) newConfig.manualSkipTime = 1;
    newConfig.enableIntro = newConfig.introTime > 0;
    newConfig.enableOutro = newConfig.outroRemain > 0;
    chrome.storage.local.set(newConfig, () => {
        currentConfig = newConfig;
        const statusDiv = document.getElementById('settingsStatus');
        statusDiv.innerHTML = '<span style="color:#52c41a;">✅ 设置已保存</span>';
        setTimeout(() => {
            if (currentConfig.autoSkipEnable) {
                statusDiv.innerHTML = '<span class="status-badge status-enabled">✅ 状态: 已启用</span>';
            } else {
                statusDiv.innerHTML = '<span class="status-badge status-disabled">⛔ 状态: 已停用</span>';
            }
        }, 1500);
    });
}

function keyConfigToText(keyConfig) {
    const parts = [];
    if (keyConfig.ctrl) parts.push('Ctrl');
    if (keyConfig.shift) parts.push('Shift');
    if (keyConfig.alt) parts.push('Alt');
    let code = keyConfig.code;
    if (code === 'ArrowRight') code = '→';
    else if (code === 'ArrowLeft') code = '←';
    else if (code === 'ArrowUp') code = '↑';
    else if (code === 'ArrowDown') code = '↓';
    else if (code === 'Space') code = '空格';
    else code = code.replace(/^Key/, '');
    parts.push(code);
    return parts.join('+');
}

let waitingForKey = null;
function startKeyCapture(type) {
    waitingForKey = type;
    const statusDiv = document.getElementById('settingsStatus');
    statusDiv.innerText = `请按下新的${type === 'forward' ? '快进' : '快退'}键组合...`;
    statusDiv.style.color = '#00aeec';
}
function stopKeyCapture() {
    waitingForKey = null;
    document.removeEventListener('keydown', keyCaptureHandler);
}
function keyCaptureHandler(e) {
    if (!waitingForKey) return;
    e.preventDefault();
    e.stopPropagation();
    const newConfig = (() => {
        let code = e.code;
        const allowed = ['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown', 'Space', 'KeyA', 'KeyB', 'KeyC', 'KeyD', 'KeyE', 'KeyF', 'KeyG', 'KeyH', 'KeyI', 'KeyJ', 'KeyK', 'KeyL', 'KeyM', 'KeyN', 'KeyO', 'KeyP', 'KeyQ', 'KeyR', 'KeyS', 'KeyT', 'KeyU', 'KeyV', 'KeyW', 'KeyX', 'KeyY', 'KeyZ', 'Digit0', 'Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5', 'Digit6', 'Digit7', 'Digit8', 'Digit9'];
        if (!allowed.includes(code)) return null;
        return {
            code: code,
            shift: e.shiftKey,
            ctrl: e.ctrlKey,
            alt: e.altKey
        };
    })();
    if (!newConfig) {
        const statusDiv = document.getElementById('settingsStatus');
        statusDiv.innerText = '无效按键，请使用方向键、字母或数字键 + Shift/Ctrl/Alt';
        statusDiv.style.color = '#ff4d4f';
        setTimeout(() => {
            if (waitingForKey) statusDiv.innerText = '';
        }, 2000);
        return;
    }
    if (waitingForKey === 'forward') {
        currentConfig.keyForward = newConfig;
        document.getElementById('forwardKeyDisplay').innerText = keyConfigToText(newConfig);
    } else if (waitingForKey === 'rewind') {
        currentConfig.keyRewind = newConfig;
        document.getElementById('rewindKeyDisplay').innerText = keyConfigToText(newConfig);
    }
    stopKeyCapture();
    const statusDiv = document.getElementById('settingsStatus');
    statusDiv.innerText = '已设置，记得点击保存';
    statusDiv.style.color = '#52c41a';
    setTimeout(() => {
        if (!waitingForKey) statusDiv.innerText = '';
    }, 2000);
}
function resetForwardKey() {
    currentConfig.keyForward = { code: 'ArrowRight', shift: true, ctrl: false, alt: false };
    document.getElementById('forwardKeyDisplay').innerText = keyConfigToText(currentConfig.keyForward);
    const statusDiv = document.getElementById('settingsStatus');
    statusDiv.innerText = '快进键已重置，记得保存';
    statusDiv.style.color = '#ff9800';
    setTimeout(() => statusDiv.innerText = '', 2000);
}
function resetRewindKey() {
    currentConfig.keyRewind = { code: 'ArrowLeft', shift: true, ctrl: false, alt: false };
    document.getElementById('rewindKeyDisplay').innerText = keyConfigToText(currentConfig.keyRewind);
    const statusDiv = document.getElementById('settingsStatus');
    statusDiv.innerText = '快退键已重置，记得保存';
    statusDiv.style.color = '#ff9800';
    setTimeout(() => statusDiv.innerText = '', 2000);
}

function showToast(text) {
    let toast = document.getElementById('popup-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'popup-toast';
        toast.style.cssText = `
            position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
            background-color: rgba(0,0,0,0.7); color: white; padding: 6px 12px;
            border-radius: 20px; font-size: 12px; z-index: 10001;
            pointer-events: none; transition: opacity 0.3s;
        `;
        document.body.appendChild(toast);
    }
    toast.innerText = text;
    toast.style.opacity = '1';
    clearTimeout(window.popupToastTimeout);
    window.popupToastTimeout = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
}

// ======================== 初始化 ========================
document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(null, (items) => {
        favData = items.favorites || {};
        collections = items.collections || {};
        ensureDefaultCollection();
        for (let key in currentConfig) {
            if (items[key] !== undefined) currentConfig[key] = items[key];
        }
        const davUrlInput = document.getElementById('dav-url');
        const davUserInput = document.getElementById('dav-user');
        const davPassInput = document.getElementById('dav-pass');
        if (davUrlInput) davUrlInput.value = items.davUrl || '';
        if (davUserInput) davUserInput.value = items.davUser || '';
        if (davPassInput) davPassInput.value = items.davPass || '';
        render();
        renderCollections();
        loadSettingsToForm();
        refreshVideoProgress();
        updatePresetPreview();
    });
    const searchInput = document.getElementById('search');
    if (searchInput) searchInput.oninput = (e) => render(e.target.value);
    const clearBtn = document.getElementById('clear-btn');
    if (clearBtn) {
        clearBtn.onclick = () => {
            if (confirm('警告：这将清空本地所有观看记录！收藏夹不受影响。')) {
                favData = {};
                saveFavorites(() => {
                    render();
                    renderCollections();
                });
            }
        };
    }
    const recordBtn = document.getElementById('record-current-page');
    if (recordBtn) recordBtn.onclick = recordCurrentPage;
    const davTestBtn = document.getElementById('dav-test');
    if (davTestBtn) {
        davTestBtn.onclick = async () => {
            const config = {
                davUrl: document.getElementById('dav-url').value.trim(),
                davUser: document.getElementById('dav-user').value.trim(),
                davPass: document.getElementById('dav-pass').value.trim()
            };
            updateStatus('正在连接...', '#00aeec');
            try {
                await chrome.storage.local.set(config);
                const res = await davRequest('GET');
                if (res.status === 401) throw new Error('账号或密码错误');
                updateStatus('✅ 连接成功并已保存配置', '#52c41a');
            } catch (e) {
                updateStatus('❌ 失败: ' + e.message, '#ff4d4f');
            }
        };
    }
    const davUploadBtn = document.getElementById('dav-upload');
    if (davUploadBtn) {
        davUploadBtn.onclick = async () => {
            updateStatus('同步中...', '#00aeec');
            try {
                const backupData = {
                    favorites: favData,
                    collections: collections
                };
                await davRequest('PUT', 'video_history.json', backupData);
                updateStatus('⬆️ 云端备份完成（含收藏夹）', '#52c41a');
            } catch (e) {
                updateStatus('❌ 上传失败: ' + e.message, '#ff4d4f');
            }
        };
    }
    const davDownloadBtn = document.getElementById('dav-download');
    if (davDownloadBtn) {
        davDownloadBtn.onclick = async () => {
            updateStatus('获取数据中...', '#00aeec');
            try {
                const res = await davRequest('GET');
                if (res.status === 404) throw new Error('云端没有找到备份文件');
                const data = await res.json();
                if (confirm('下载的数据将覆盖本地记录和收藏夹，确定吗？')) {
                    if (data.favorites) {
                        favData = data.favorites;
                        collections = data.collections || {};
                    } else {
                        favData = data;
                        collections = {};
                    }
                    ensureDefaultCollection();
                    await chrome.storage.local.set({ favorites: favData, collections: collections });
                    render();
                    renderCollections();
                    updateStatus('⬇️ 云端数据已同步至本地（含收藏夹）', '#52c41a');
                }
            } catch (e) {
                updateStatus('❌ 下载失败: ' + e.message, '#ff4d4f');
            }
        };
    }
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.onclick = () => switchTab(btn.dataset.tab);
    });
    const newFolderBtn = document.getElementById('new-folder-btn');
    if (newFolderBtn) newFolderBtn.onclick = createNewFolder;
    // 剧集预设快速设置按钮
    const setIntroBtn = document.getElementById('setIntroFromCurrent');
    if (setIntroBtn) setIntroBtn.onclick = setIntroFromCurrent;
    const setOutroBtn = document.getElementById('setOutroFromCurrent');
    if (setOutroBtn) setOutroBtn.onclick = setOutroFromCurrent;
    const refreshProgressBtn = document.getElementById('refreshProgress');
    if (refreshProgressBtn) refreshProgressBtn.onclick = refreshVideoProgress;
    // 监听标签页变化，刷新进度和预设预览
    chrome.tabs.onActivated.addListener(() => {
        if (currentTab === 'settings') {
            refreshVideoProgress();
            updatePresetPreview();
            renderPresetsList();
        }
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
        if (changeInfo.status === 'complete' && tab.active && currentTab === 'settings') {
            refreshVideoProgress();
            updatePresetPreview();
            renderPresetsList();
        }
    });
    // 设置页面其他按钮
    const saveSettingsBtn = document.getElementById('saveSettings');
    if (saveSettingsBtn) saveSettingsBtn.onclick = saveSettings;
    const setForwardBtn = document.getElementById('setForwardKey');
    if (setForwardBtn) {
        setForwardBtn.onclick = () => {
            startKeyCapture('forward');
            document.addEventListener('keydown', keyCaptureHandler);
        };
    }
    const setRewindBtn = document.getElementById('setRewindKey');
    if (setRewindBtn) {
        setRewindBtn.onclick = () => {
            startKeyCapture('rewind');
            document.addEventListener('keydown', keyCaptureHandler);
        };
    }
    const resetForwardBtn = document.getElementById('resetForwardKey');
    if (resetForwardBtn) resetForwardBtn.onclick = resetForwardKey;
    const resetRewindBtn = document.getElementById('resetRewindKey');
    if (resetRewindBtn) resetRewindBtn.onclick = resetRewindKey;
    // 监听 storage 变化，同步配置
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local') {
            let reloadSettings = false;
            for (let key in currentConfig) {
                if (changes[key]) {
                    currentConfig[key] = changes[key].newValue;
                    reloadSettings = true;
                }
            }
            if (reloadSettings && currentTab === 'settings') {
                loadSettingsToForm();
                updatePresetPreview();
                renderPresetsList();
            }
        }
    });
});