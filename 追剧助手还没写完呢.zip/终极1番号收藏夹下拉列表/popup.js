let favData = {};
let collections = {};
let currentTab = 'history';

// 保存收藏夹
function saveCollections() {
    chrome.storage.local.set({ collections: collections });
}

// 加载收藏夹
function loadCollections(callback) {
    chrome.storage.local.get(['collections'], (res) => {
        collections = res.collections || {};
        if (callback) callback();
    });
}

// 渲染收藏夹列表
function renderCollections() {
    const container = document.getElementById('collections-list');
    if (!container) return;
    const folderNames = Object.keys(collections).sort();
    if (folderNames.length === 0) {
        container.innerHTML = `<div style="text-align:center;color:#999;margin-top:40px;font-size:13px;">暂无收藏夹，点击下方按钮创建</div>`;
        return;
    }
    let html = '';
    for (const folderName of folderNames) {
        const seriesKeys = collections[folderName] || [];
        const itemsHtml = seriesKeys.map(key => {
            const record = favData[key];
            const title = record ? `${record.series} (${record.episode})` : key;
            const url = record ? record.url : '#';
            return `
                <div class="folder-item">
                    <a href="${url}" target="_blank" class="folder-item-title" title="${title}">${title}</a>
                    <span class="remove-fav-btn" data-folder="${folderName}" data-key="${key}">✖</span>
                </div>
            `;
        }).join('') || '<div class="empty-folder">暂无剧集</div>';
        html += `
            <div class="folder" data-folder="${folderName}">
                <div class="folder-header">
                    <span class="folder-name">📁 ${folderName}</span>
                    <div class="folder-actions">
                        <span class="delete-folder" data-folder="${folderName}" title="删除文件夹">🗑️</span>
                        <span class="toggle-folder" data-folder="${folderName}">▼</span>
                    </div>
                </div>
                <div class="folder-content">${itemsHtml}</div>
            </div>
        `;
    }
    container.innerHTML = html;

    document.querySelectorAll('.delete-folder').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const folder = btn.dataset.folder;
            if (confirm(`确定删除文件夹「${folder}」及其中的所有剧集吗？`)) {
                delete collections[folder];
                saveCollections();
                renderCollections();
            }
        };
    });
    document.querySelectorAll('.toggle-folder').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const folder = btn.closest('.folder');
            const content = folder.querySelector('.folder-content');
            content.classList.toggle('open');
            btn.textContent = content.classList.contains('open') ? '▲' : '▼';
        };
    });
    document.querySelectorAll('.remove-fav-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const folder = btn.dataset.folder;
            const key = btn.dataset.key;
            if (collections[folder]) {
                collections[folder] = collections[folder].filter(k => k !== key);
                if (collections[folder].length === 0) delete collections[folder];
                saveCollections();
                renderCollections();
                render();
            }
        };
    });
}

// 显示文件夹选择器（下拉选择或新建）
function showFolderSelector(seriesKey, seriesTitle, callback) {
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
    overlay.style.zIndex = '10000';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    
    const dialog = document.createElement('div');
    dialog.style.backgroundColor = '#fff';
    dialog.style.borderRadius = '8px';
    dialog.style.padding = '20px';
    dialog.style.width = '280px';
    dialog.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    
    const titleEl = document.createElement('div');
    titleEl.textContent = `添加到收藏夹：${seriesTitle}`;
    titleEl.style.fontWeight = 'bold';
    titleEl.style.marginBottom = '12px';
    titleEl.style.fontSize = '14px';
    
    const select = document.createElement('select');
    select.style.width = '100%';
    select.style.padding = '8px';
    select.style.marginBottom = '12px';
    select.style.borderRadius = '4px';
    select.style.border = '1px solid #ddd';
    
    const folderNames = Object.keys(collections);
    if (folderNames.length === 0) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = '暂无文件夹，请先新建';
        select.appendChild(option);
    } else {
        folderNames.forEach(folder => {
            const option = document.createElement('option');
            option.value = folder;
            option.textContent = folder;
            select.appendChild(option);
        });
    }
    
    const newFolderBtn = document.createElement('button');
    newFolderBtn.textContent = '新建文件夹';
    newFolderBtn.style.backgroundColor = '#00aeec';
    newFolderBtn.style.color = '#fff';
    newFolderBtn.style.border = 'none';
    newFolderBtn.style.padding = '8px';
    newFolderBtn.style.borderRadius = '4px';
    newFolderBtn.style.width = '100%';
    newFolderBtn.style.marginBottom = '12px';
    newFolderBtn.style.cursor = 'pointer';
    
    const confirmBtn = document.createElement('button');
    confirmBtn.textContent = '确认';
    confirmBtn.style.backgroundColor = '#52c41a';
    confirmBtn.style.color = '#fff';
    confirmBtn.style.border = 'none';
    confirmBtn.style.padding = '8px';
    confirmBtn.style.borderRadius = '4px';
    confirmBtn.style.width = '48%';
    confirmBtn.style.cursor = 'pointer';
    confirmBtn.style.marginRight = '4%';
    
    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = '取消';
    cancelBtn.style.backgroundColor = '#ddd';
    cancelBtn.style.color = '#333';
    cancelBtn.style.border = 'none';
    cancelBtn.style.padding = '8px';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.width = '48%';
    cancelBtn.style.cursor = 'pointer';
    
    const btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.justifyContent = 'space-between';
    btnContainer.appendChild(confirmBtn);
    btnContainer.appendChild(cancelBtn);
    
    dialog.appendChild(titleEl);
    dialog.appendChild(select);
    dialog.appendChild(newFolderBtn);
    dialog.appendChild(btnContainer);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    
    newFolderBtn.onclick = () => {
        const newFolderName = prompt('请输入新文件夹名称：');
        if (newFolderName && !collections[newFolderName]) {
            collections[newFolderName] = [];
            saveCollections();
            const option = document.createElement('option');
            option.value = newFolderName;
            option.textContent = newFolderName;
            select.appendChild(option);
            select.value = newFolderName;
            renderCollections();
        } else if (newFolderName && collections[newFolderName]) {
            alert('文件夹已存在');
        }
    };
    
    confirmBtn.onclick = () => {
        const selectedFolder = select.value;
        if (!selectedFolder) {
            alert('请选择或新建文件夹');
            return;
        }
        if (!collections[selectedFolder]) {
            collections[selectedFolder] = [];
        }
        if (!collections[selectedFolder].includes(seriesKey)) {
            collections[selectedFolder].push(seriesKey);
            saveCollections();
            alert(`已添加《${seriesTitle}》到「${selectedFolder}」`);
            renderCollections();
            render();
        } else {
            alert('该剧集已在当前文件夹中');
        }
        overlay.remove();
        if (callback) callback();
    };
    
    cancelBtn.onclick = () => {
        overlay.remove();
        if (callback) callback();
    };
}

// 添加剧集到收藏夹
function addToCollection(seriesKey, seriesTitle) {
    showFolderSelector(seriesKey, seriesTitle);
}

// 检查是否已收藏
function isInAnyCollection(seriesKey) {
    for (const folder in collections) {
        if (collections[folder].includes(seriesKey)) return true;
    }
    return false;
}

// 渲染观看记录列表
function render(filter = '') {
    const list = document.getElementById('list');
    if (!list) return;
    const keys = Object.keys(favData)
        .filter(k => k.toLowerCase().includes(filter.toLowerCase()))
        .sort((a, b) => favData[b].ts - favData[a].ts);
    if (keys.length === 0) {
        list.innerHTML = `<div style="text-align:center;color:#999;margin-top:40px;font-size:13px;">${filter ? '无搜索结果' : '暂无记录，快去追剧吧~'}</div>`;
        return;
    }
    list.innerHTML = keys.map(k => {
        const item = favData[k];
        const prog = Math.floor((item.time / item.duration) * 100) || 0;
        const dateStr = new Date(item.ts).toLocaleDateString().slice(5);
        const isFav = isInAnyCollection(k);
        return `
            <div class="item">
                <a href="${item.url}" target="_blank" class="content">
                    <div class="title" title="${item.series}">${item.series}</div>
                    <div class="info">
                        <span class="ep-tag">${item.episode}</span>
                        <span class="prog-tag">进度 ${prog}%</span>
                        <span class="time-tag">${dateStr}</span>
                    </div>
                    <div class="prog-track">
                        <div class="prog-fill" style="width: ${prog}%"></div>
                    </div>
                </a>
                <span class="fav-btn" data-key="${k}" data-title="${item.series}" title="${isFav ? '已收藏' : '添加到收藏夹'}">${isFav ? '⭐' : '☆'}</span>
                <span class="del-btn" data-key="${k}" title="删除此记录">×</span>
            </div>
        `;
    }).join('');

    document.querySelectorAll('.del-btn').forEach(b => {
        b.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const key = e.target.dataset.key;
            if (confirm(`确定删除《${favData[key]?.series || key}》的观看记录吗？`)) {
                delete favData[key];
                chrome.storage.local.set({ favorites: favData }, () => {
                    const searchBox = document.getElementById('search');
                    render(searchBox ? searchBox.value : '');
                    renderCollections();
                });
            }
        };
    });
    document.querySelectorAll('.fav-btn').forEach(b => {
        b.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const key = b.dataset.key;
            const title = b.dataset.title;
            if (isInAnyCollection(key)) {
                if (confirm(`是否从收藏夹中移除《${title}》？`)) {
                    for (const folder in collections) {
                        const idx = collections[folder].indexOf(key);
                        if (idx !== -1) {
                            collections[folder].splice(idx, 1);
                            if (collections[folder].length === 0) delete collections[folder];
                            break;
                        }
                    }
                    saveCollections();
                    render();
                    renderCollections();
                }
            } else {
                addToCollection(key, title);
            }
        };
    });
}

// WebDAV 请求
async function davRequest(method, path = 'video_history.json', body = null) {
    const config = await chrome.storage.local.get(['davUrl', 'davUser', 'davPass']);
    if (!config.davUrl || !config.davUser || !config.davPass) throw new Error('同步配置不完整');
    const auth = btoa(`${config.davUser}:${config.davPass}`);
    const baseUrl = config.davUrl.endsWith('/') ? config.davUrl : config.davUrl + '/';
    const options = {
        method,
        headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
        }
    };
    if (body) options.body = JSON.stringify(body);
    const response = await fetch(baseUrl + path, options);
    if (!response.ok && method !== 'GET') throw new Error(`服务器返回: ${response.status}`);
    return response;
}

const updateStatus = (msg, color = '#888') => {
    const el = document.getElementById('dav-status');
    if (el) {
        el.innerText = msg;
        el.style.color = color;
    }
};

// 标签页切换
function switchTab(tabId) {
    currentTab = tabId;
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabId);
    });
    document.getElementById('history-tab').classList.toggle('active', tabId === 'history');
    document.getElementById('favorites-tab').classList.toggle('active', tabId === 'favorites');
    if (tabId === 'favorites') renderCollections();
}

// 新建文件夹（独立按钮）
function createNewFolder() {
    const folderName = prompt('请输入文件夹名称：');
    if (!folderName) return;
    if (collections[folderName]) {
        alert('文件夹已存在');
        return;
    }
    collections[folderName] = [];
    saveCollections();
    renderCollections();
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['favorites', 'collections', 'davUrl', 'davUser', 'davPass'], res => {
        favData = res.favorites || {};
        collections = res.collections || {};
        const davUrlInput = document.getElementById('dav-url');
        const davUserInput = document.getElementById('dav-user');
        const davPassInput = document.getElementById('dav-pass');
        if (davUrlInput) davUrlInput.value = res.davUrl || '';
        if (davUserInput) davUserInput.value = res.davUser || '';
        if (davPassInput) davPassInput.value = res.davPass || '';
        render();
        renderCollections();
    });

    const searchInput = document.getElementById('search');
    if (searchInput) searchInput.oninput = (e) => render(e.target.value);

    const clearBtn = document.getElementById('clear-btn');
    if (clearBtn) {
        clearBtn.onclick = () => {
            if (confirm('警告：这将清空本地所有观看记录！')) {
                favData = {};
                chrome.storage.local.set({ favorites: {} }, () => {
                    render();
                    renderCollections();
                });
            }
        };
    }

    const davTestBtn = document.getElementById('dav-test');
    if (davTestBtn) {
        davTestBtn.onclick = async () => {
            const config = {
                davUrl: document.getElementById('dav-url').value.trim(),
                davUser: document.getElementById('dav-user').value.trim(),
                davPass: document.getElementById('dav-pass').value.trim()
            };
            updateStatus('正在连接...', '#00aeec');
            try {
                await chrome.storage.local.set(config);
                const res = await davRequest('GET');
                if (res.status === 401) throw new Error('账号或密码错误');
                updateStatus('✅ 连接成功并已保存配置', '#52c41a');
            } catch (e) {
                updateStatus('❌ 失败: ' + e.message, '#ff4d4f');
            }
        };
    }

    const davUploadBtn = document.getElementById('dav-upload');
    if (davUploadBtn) {
        davUploadBtn.onclick = async () => {
            updateStatus('同步中...', '#00aeec');
            try {
                const backupData = {
                    favorites: favData,
                    collections: collections
                };
                await davRequest('PUT', 'video_history.json', backupData);
                updateStatus('⬆️ 云端备份完成（含收藏夹）', '#52c41a');
            } catch (e) {
                updateStatus('❌ 上传失败: ' + e.message, '#ff4d4f');
            }
        };
    }

    const davDownloadBtn = document.getElementById('dav-download');
    if (davDownloadBtn) {
        davDownloadBtn.onclick = async () => {
            updateStatus('获取数据中...', '#00aeec');
            try {
                const res = await davRequest('GET');
                if (res.status === 404) throw new Error('云端没有找到备份文件');
                const data = await res.json();
                if (confirm('下载的数据将覆盖本地记录和收藏夹，确定吗？')) {
                    if (data.favorites) {
                        favData = data.favorites;
                        collections = data.collections || {};
                    } else {
                        favData = data;
                        collections = {};
                    }
                    await chrome.storage.local.set({ favorites: favData, collections: collections });
                    render();
                    renderCollections();
                    updateStatus('⬇️ 云端数据已同步至本地（含收藏夹）', '#52c41a');
                }
            } catch (e) {
                updateStatus('❌ 下载失败: ' + e.message, '#ff4d4f');
            }
        };
    }

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.onclick = () => switchTab(btn.dataset.tab);
    });

    const newFolderBtn = document.getElementById('new-folder-btn');
    if (newFolderBtn) newFolderBtn.onclick = createNewFolder;
});