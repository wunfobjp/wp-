(function() {
    let lastUrl = window.location.href;
    const boundVideos = new WeakSet();
    let isJumped = false;

    // ========= 辅助函数：数字转中文数字（1~99） =========
    function numberToChinese(num) {
        const chineseNums = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
        if (num === 0) return '零';
        if (num <= 10) return chineseNums[num];
        if (num < 20) return '十' + (num % 10 === 0 ? '' : chineseNums[num % 10]);
        const tens = Math.floor(num / 10);
        const ones = num % 10;
        return chineseNums[tens] + '十' + (ones === 0 ? '' : chineseNums[ones]);
    }

    // 辅助：中文数字转阿拉伯数字（支持1~99）
    function chineseToNumber(chStr) {
        const chMap = { '一':1, '二':2, '三':3, '四':4, '五':5, '六':6, '七':7, '八':8, '九':9, '十':10 };
        if (chStr.length === 1) return chMap[chStr] || 0;
        if (chStr === '十') return 10;
        if (chStr.startsWith('十')) return 10 + (chMap[chStr[1]] || 0);
        if (chStr.endsWith('十')) return (chMap[chStr[0]] || 0) * 10;
        if (chStr.includes('十')) {
            const parts = chStr.split('十');
            const left = parts[0] ? chMap[parts[0]] : 1;
            const right = parts[1] ? chMap[parts[1]] : 0;
            return left * 10 + right;
        }
        return 0;
    }

    // ========= 安全调用扩展 API =========
    async function safeSendMessage(message) {
        if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
            console.warn("[追剧助手] chrome.runtime 不可用，跳过消息");
            return null;
        }
        try {
            return await chrome.runtime.sendMessage(message);
        } catch (e) {
            console.warn("[追剧助手] 发送消息失败", e);
            return null;
        }
    }

    function safeStorageGet(keys, callback) {
        if (!chrome || !chrome.storage || !chrome.storage.local) {
            console.warn("[追剧助手] chrome.storage 不可用");
            callback({});
            return;
        }
        chrome.storage.local.get(keys, callback);
    }

    // ========= 从 URL 提取集数（支持多网站） =========
    function extractEpisodeFromURL(url) {
        if (!url) return null;
        function validNum(num) {
            let n = parseInt(num, 10);
            return n > 0 && n <= 9999;
        }
        let match = url.match(/\/vod-play\/\d+-\d+-(\d+)\//);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/play\/\d+-(\d+)-(\d+)\.html/);
        if (match && validNum(match[2])) return `第${parseInt(match[2])}集`;
        match = url.match(/[?&]ep=第(\d+)集/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/vodplay\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/play\/\d+_(\d+)_(\d+)\.html/);
        if (match && validNum(match[2])) return `第${parseInt(match[2])}集`;
        match = url.match(/\/play\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        match = url.match(/\/player\/vod\/\d+-\d+-(\d+)\.html/);
        if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        const patterns = [
            /[\/-](\d{1,4})(?:\/|$)/,
            /[?&]ep(?:isode)?=(\d{1,4})/i,
            /[\/-]ep(\d{1,4})/i,
            /[\/-]p(\d{1,4})/i,
        ];
        for (const pattern of patterns) {
            const m = url.match(pattern);
            if (m && validNum(m[1])) return `第${parseInt(m[1])}集`;
        }
        return null;
    }

    // ========= 从 DOM 同步提取集数 =========
    function tryExtractEpisodeFromDOM() {
        function validEpisodeText(epText) {
            let numMatch = epText.match(/\d+/);
            if (numMatch) {
                let num = parseInt(numMatch[0], 10);
                return num >= 1 && num <= 9999;
            }
            return false;
        }

        // olevod.com
        const oleActiveLi = document.querySelector('li.active_s.active_b.active');
        if (oleActiveLi) {
            let title = oleActiveLi.getAttribute('title');
            if (title) {
                let match = title.match(/第(\d+)集/);
                if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
            }
            let text = oleActiveLi.innerText.trim();
            let match = text.match(/第(\d+)集/);
            if (match && validNum(match[1])) return `第${parseInt(match[1])}集`;
        }

        // 4kvm.tv
        const activeEpisode = document.querySelector('.episode-link.bg-dark-700\\/60.text-white');
        if (activeEpisode) {
            let episodeNum = activeEpisode.getAttribute('data-episode');
            if (episodeNum && !isNaN(parseInt(episodeNum)) && parseInt(episodeNum) <= 9999) {
                return `第${parseInt(episodeNum)}集`;
            }
            const span = activeEpisode.querySelector('span');
            if (span && span.innerText) {
                let text = span.innerText.trim();
                let match = text.match(/^(\d{1,4})$/);
                if (match && parseInt(match[1]) <= 9999) return `第${parseInt(match[1])}集`;
            }
        }

        // moovie.c2v2.com
        const moovieLink = document.querySelector('.ep-btn.active');
        if (moovieLink && moovieLink.innerText) {
            let text = moovieLink.innerText.trim();
            let match = text.match(/(第\s*\d{1,4}\s*[集话期])|(\d{1,4})\s*[集话期]?/);
            if (match) {
                let ep = match[0];
                if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                if (!/线路|资源|播放|更新/.test(ep) && validEpisodeText(ep)) return ep;
            }
        }

        // hemayi
        const hemayiLink = document.querySelector('.stui-play__list li.active a');
        if (hemayiLink && hemayiLink.innerText) {
            let text = hemayiLink.innerText.trim();
            let match = text.match(/(第\s*\d{1,4}\s*[集话期])|(\d{1,4})\s*[集话期]?/);
            if (match) {
                let ep = match[0];
                if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                if (!/线路|资源|播放|更新/.test(ep) && validEpisodeText(ep)) return ep;
            }
        }

        // ttdm6
        const ttdm6Link = document.querySelector('.module-play-list-link.active');
        if (ttdm6Link && ttdm6Link.innerText) {
            let text = ttdm6Link.innerText.trim();
            let match = text.match(/(第\s*\d{1,4}\s*[集话期])|(\d{1,4})\s*[集话期]?/);
            if (match) {
                let ep = match[0];
                if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                if (!/线路|资源|播放|更新/.test(ep) && validEpisodeText(ep)) return ep;
            }
        }

        const selectors = [
            '.play-item.cont.active li.active a',
            'li.active a', 'li.on a',
            '.module-play-list-link.current',
            '.episode-item-active',
            '[aria-current="page"]',
            '.stui-play__list li.active a',
            '.playlist li.active a',
            '.ep-list li.active a',
            '.episode-item-active',
            '.active', '.on', '.current'
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText) {
                let text = el.innerText.trim();
                let match = text.match(/(第\s*\d{1,4}\s*[集话期])|(\d{1,4})\s*[集话期]?/);
                if (match) {
                    let ep = match[0];
                    if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                    if (!/线路|资源|播放|更新/.test(ep) && validEpisodeText(ep)) return ep;
                }
            }
        }
        return null;
    }

    function waitForElement(selector, timeout = 10000, interval = 200) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el) return resolve(el);
                if (Date.now() - start >= timeout) return resolve(null);
                setTimeout(check, interval);
            };
            check();
        });
    }

    async function getEpisodeFromDOMWithRetry() {
        const url = window.location.href;
        if (url.match(/\/vod\/\d+\/$/)) {
            console.log("[追剧助手] ttdm6 详情页，等待播放列表激活元素...");
            const activeLink = await waitForElement('.module-play-list-link.active', 10000, 200);
            if (activeLink) {
                const text = activeLink.innerText.trim();
                let match = text.match(/(第\s*\d{1,4}\s*[集话期])|(\d{1,4})\s*[集话期]?/);
                if (match) {
                    let ep = match[0];
                    if (/^\d+$/.test(ep) && parseInt(ep) <= 9999) ep = `第${parseInt(ep)}集`;
                    if (!/线路|资源|播放|更新/.test(ep)) return ep;
                }
            }
            return "正片";
        }

        let maxRetries = 5;
        let delay = 300;
        if (url.includes('hemayi.com') || url.includes('4kvm.tv') || url.includes('beijingbaroque.com') || url.includes('yao-da.com') || url.includes('gangjuw.tv') || url.includes('olevod.com')) {
            maxRetries = 10;
            delay = 500;
        }
        for (let i = 0; i < maxRetries; i++) {
            const ep = tryExtractEpisodeFromDOM();
            if (ep) return ep;
            await new Promise(r => setTimeout(r, delay));
        }
        return "正片";
    }

    // ========= 剧名清洗（保留番号、季信息、国语/粤语标签） =========
    function cleanSeriesName(rawTitle, url) {
        if (!rawTitle) return "未知视频";

        let titleTemp = rawTitle.trim();

        // 特殊处理：如果标题包含典型的番号模式（如 FC2-PPV-数字、FC2-数字 等），则直接保留原标题（仅去除集数信息）
        const codePattern = /\b(?:FC2|FC2-PPV|HEYZO|Caribbean|一本道|加勒比|天然むすめ|東京熱|Tokyo-Hot)[-_]?\d+/i;
        if (codePattern.test(titleTemp)) {
            // 尝试移除集数部分（如 "第1集"），但保留番号
            let cleaned = titleTemp.replace(/第\d+集/g, '').trim();
            if (cleaned) return cleaned;
            return titleTemp;
        }

        let seasonText = '';
        let langTag = "";

        // 提取季信息
        const seasonPattern = /(?:第\s*(\d+)\s*季|第\s*([一二三四五六七八九十]+)\s*季|(\d+)\s*季|([一二三四五六七八九十]+)\s*季)/i;
        let match = titleTemp.match(seasonPattern);
        if (match) {
            let seasonNum = null;
            if (match[1]) seasonNum = parseInt(match[1], 10);
            else if (match[2]) seasonNum = chineseToNumber(match[2]);
            else if (match[3]) seasonNum = parseInt(match[3], 10);
            else if (match[4]) seasonNum = chineseToNumber(match[4]);
            if (seasonNum && seasonNum >= 1 && seasonNum <= 99) {
                const chineseSeason = numberToChinese(seasonNum);
                seasonText = `第${chineseSeason}季`;
                titleTemp = titleTemp.replace(seasonPattern, '').trim();
            }
        }

        // keke1.app 专用
        if (url.includes('keke1.app')) {
            try {
                const detailLink = document.querySelector('.detail-title a strong, .play-box-side-header .detail-title a strong, a[href^="/detail/"] strong');
                if (detailLink && detailLink.innerText) {
                    let series = detailLink.innerText.trim();
                    if (series) {
                        if (series.includes('第') && series.includes('季')) return series;
                        return series + seasonText;
                    }
                }
            } catch(e) {}
        }

        let title = titleTemp;

        // 4kvm.tv
        if (url.includes('4kvm.tv') && title.includes(':')) {
            title = title.split(':')[0];
        }
        // gangjuw.tv
        if (url.includes('gangjuw.tv')) {
            const epIndex = title.indexOf('第');
            if (epIndex > 0) title = title.substring(0, epIndex);
        }
        // olevod.com
        if (url.includes('olevod.com')) {
            const langMatch = title.match(/[【【](国语|粤语)[】】]/);
            if (langMatch) {
                langTag = langMatch[1];
                title = title.replace(/[【【](?:国语|粤语)[】】]/g, '').trim();
            }
            title = title.replace(/[【【][^】】]*[】】]/g, '').trim();
        }

        // 如果还没有语言标签，从标题中提取
        if (!langTag) {
            if (title.includes("粤语")) langTag = "粤语";
            else if (title.includes("国语")) langTag = "国语";
        }

        // 尾部噪声
        const tailNoise = /(\.com|\.app|\.net|\.cc|免费|爱看|在线|高清|完整|播放|正在|视频|官方|最新|频道|4k影视|4K影视|影视|可可影视|线上看|港剧网)/i;
        const tailMatch = title.match(tailNoise);
        if (tailMatch) title = title.substring(0, tailMatch.index);

        // 书名号
        const bracketMatch = title.match(/《(.*?)》/);
        if (bracketMatch) title = bracketMatch[1];

        // 清除干扰符号
        title = title.replace(/[《》()（）\[\]【】\s\-\|_—]/g, "").trim();

        // 噪声词（不删除番号）
        const noiseWords = [
            /在线观看|免费播放|高清|完整版|正片|正在播放|正在|播放/gi,
            /电视剧|电影|动漫|综艺|机器人|ikanbot|可可影视|影牛|欧乐影院|olevod/gi,
            /粤语/g, /国语/g, /免费/g, /爱看/g,
            /4k影视|4K影视|影视/g,
            /\d{5,}/g   // 删除过长数字，但番号中的数字较短，不会误删
        ];
        noiseWords.forEach(word => title = title.replace(word, ""));

        let finalSeries = (title + langTag).trim();
        if (!finalSeries) finalSeries = "未知视频";

        if (seasonText) {
            finalSeries = finalSeries + seasonText;
        }

        return finalSeries;
    }

    // ========= 统一获取剧名和集数 =========
    async function getVideoInfo(finalTitle, finalUrl) {
        let episode = extractEpisodeFromURL(finalUrl);
        if (!episode) {
            episode = await getEpisodeFromDOMWithRetry();
        }
        const series = cleanSeriesName(finalTitle, finalUrl);
        console.log(`[追剧助手] 最终 -> 剧名: ${series}, 集数: ${episode}, URL: ${finalUrl}`);
        return { series, episode };
    }

    // ========= 自动续播 =========
    async function autoJump(video) {
        if (isJumped || video.currentTime > 15) return;

        let finalTitle = document.title;
        let finalUrl = window.location.href;
        if (window.self !== window.top) {
            const response = await safeSendMessage({ action: "GET_TOP_INFO" });
            if (response) {
                finalTitle = response.title;
                finalUrl = response.url;
            }
        }

        const currentInfo = await getVideoInfo(finalTitle, finalUrl);
        if (currentInfo.episode === "正片") {
            console.log("[追剧助手] 当前集数为'正片'，放弃自动续播");
            return;
        }

        safeStorageGet(['favorites'], (res) => {
            const favs = res.favorites || {};
            const record = favs[currentInfo.series];
            if (record && record.episode === currentInfo.episode && record.time > 10) {
                const storedNum = record.url.match(/(\d+)(?:\/|\.html|$)/);
                const currentNum = finalUrl.match(/(\d+)(?:\/|\.html|$)/);
                if (storedNum && currentNum && storedNum[1] !== currentNum[1]) {
                    console.log(`[追剧助手] URL集数不一致，放弃跳转`);
                    return;
                }
                if (video.duration && record.time > video.duration - 20) return;
                video.currentTime = record.time;
                isJumped = true;
                showJumpTip(record.time);
            }
        });
    }

    // ========= 进度同步 =========
    async function updateProgress(video) {
        if (isNaN(video.duration) || video.duration < 30 || video.currentTime < 5) return;

        let finalUrl = window.location.href;
        let finalTitle = document.title;
        if (window.self !== window.top) {
            const response = await safeSendMessage({ action: "GET_TOP_INFO" });
            if (response) {
                finalTitle = response.title;
                finalUrl = response.url;
            }
        }

        const info = await getVideoInfo(finalTitle, finalUrl);
        safeSendMessage({
            action: "UPDATE_FAV",
            data: {
                series: info.series,
                episode: info.episode,
                time: Math.floor(video.currentTime),
                duration: Math.floor(video.duration),
                url: finalUrl
            }
        });
    }

    // ========= 视频探测与绑定 =========
    function findVideos(root) {
        let videos = Array.from(root.querySelectorAll('video'));
        root.querySelectorAll('*').forEach(el => {
            if (el.shadowRoot) videos = videos.concat(findVideos(el.shadowRoot));
        });
        return videos;
    }

    function bindEvents() {
        const videos = findVideos(document);
        const mainVideo = videos
            .filter(v => !isNaN(v.duration) && v.duration > 30)
            .sort((a, b) => b.duration - a.duration)[0];

        if (mainVideo && !boundVideos.has(mainVideo)) {
            console.log("[追剧助手] 检测到视频元素，绑定事件");
            if (mainVideo.readyState >= 1) autoJump(mainVideo);
            else mainVideo.addEventListener('loadedmetadata', () => autoJump(mainVideo));

            let lastUpdate = 0;
            mainVideo.addEventListener('timeupdate', () => {
                if (Date.now() - lastUpdate > 10000) {
                    updateProgress(mainVideo);
                    lastUpdate = Date.now();
                }
            });
            boundVideos.add(mainVideo);
        }
    }

    function showJumpTip(totalSeconds) {
        const min = Math.floor(totalSeconds / 60);
        const sec = totalSeconds % 60;
        const tip = document.createElement('div');
        tip.innerHTML = `🎬 已为你续播到 ${min}分${sec}秒`;
        Object.assign(tip.style, {
            position: 'fixed', top: '35px', left: '50%', transform: 'translateX(-50%)',
            backgroundColor: 'rgba(0, 174, 236, 0.95)', color: 'white', padding: '10px 25px',
            borderRadius: '30px', zIndex: '2147483647', fontSize: '14px', fontWeight: 'bold',
            boxShadow: '0 4px 15px rgba(0,0,0,0.2)', pointerEvents: 'none', transition: 'all 0.5s'
        });
        document.body.appendChild(tip);
        setTimeout(() => {
            tip.style.opacity = '0';
            tip.style.top = '20px';
            setTimeout(() => tip.remove(), 500);
        }, 3000);
    }

    const observer = new MutationObserver(() => bindEvents());
    observer.observe(document.documentElement, { childList: true, subtree: true });

    setInterval(() => {
        if (window.location.href !== lastUrl) {
            lastUrl = window.location.href;
            isJumped = false;
            bindEvents();
        }
    }, 2000);

    setTimeout(bindEvents, 2000);
})();